import * as React from "react";
import { ScrollView, Text, StyleSheet, View } from "react-native";
import { FontSize, FontFamily, Color, Border } from "../GlobalStyles";

const SearchResults1 = () => {
  return (
    <View style={styles.searchResults}>
      <ScrollView
        style={styles.searchResultsBody}
        showsHorizontalScrollIndicator={false}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.searchResultsBodyContent}
      >
        <View style={styles.listItems}>
          <View style={styles.mobileButtonParent}>
            <View style={[styles.mobileButton, styles.mobilePosition]}>
              <Text style={styles.mobileNumber}>Mobile Number</Text>
              <View style={[styles.mobileButtonChild, styles.mt8]} />
            </View>
            <View style={[styles.mobileButton1, styles.mobilePosition]}>
              <Text style={styles.mobileNumber}>Mobile Number</Text>
              <View style={[styles.mobileButtonChild, styles.mt8]} />
            </View>
            <View style={[styles.nameButton, styles.buttonPosition]}>
              <Text style={styles.mobileNumber}>Full Name</Text>
              <View style={[styles.mobileButtonChild, styles.mt8]} />
            </View>
          </View>
          <View style={styles.mobileButtonParent}>
            <View style={[styles.mobileButton, styles.mobilePosition]}>
              <Text style={styles.mobileNumber}>Mobile Number</Text>
              <View style={[styles.mobileButtonChild, styles.mt8]} />
            </View>
            <View style={[styles.mobileButton1, styles.mobilePosition]}>
              <Text style={styles.mobileNumber}>Mobile Number</Text>
              <View style={[styles.mobileButtonChild, styles.mt8]} />
            </View>
            <View style={[styles.nameButton, styles.buttonPosition]}>
              <Text style={styles.mobileNumber}>Full Name</Text>
              <View style={[styles.mobileButtonChild, styles.mt8]} />
            </View>
          </View>
          <View style={styles.mobileButtonParent}>
            <View style={[styles.mobileButton, styles.mobilePosition]}>
              <Text style={styles.mobileNumber}>Mobile Number</Text>
              <View style={[styles.mobileButtonChild, styles.mt8]} />
            </View>
            <View style={[styles.mobileButton1, styles.mobilePosition]}>
              <Text style={styles.mobileNumber}>Mobile Number</Text>
              <View style={[styles.mobileButtonChild, styles.mt8]} />
            </View>
            <View style={[styles.nameButton, styles.buttonPosition]}>
              <Text style={styles.mobileNumber}>Full Name</Text>
              <View style={[styles.mobileButtonChild, styles.mt8]} />
            </View>
            <View style={[styles.signupButton, styles.signupLayout]}>
              <View
                style={[
                  styles.signupButtonChild,
                  styles.signupLayout,
                  styles.buttonPosition,
                ]}
              />
              <Text style={styles.create}>Create</Text>
            </View>
          </View>
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  mt8: {
    marginTop: 8,
  },
  searchResultsBodyContent: {
    flexDirection: "column",
    paddingHorizontal: 16,
    paddingVertical: 20,
  },
  mobilePosition: {
    left: 0,
    position: "absolute",
  },
  buttonPosition: {
    top: 0,
    left: 0,
  },
  signupLayout: {
    height: 37,
    position: "absolute",
    width: 274,
  },
  mobileNumber: {
    fontSize: FontSize.size_sm,
    fontFamily: FontFamily.lato,
    color: Color.lightLabelPrimary,
    textAlign: "left",
    alignSelf: "stretch",
  },
  mobileButtonChild: {
    backgroundColor: Color.lightLabelPrimary,
    height: 2,
    alignSelf: "stretch",
  },
  mobileButton: {
    top: 70,
    width: 274,
  },
  mobileButton1: {
    top: 142,
    width: 272,
  },
  nameButton: {
    position: "absolute",
    width: 274,
  },
  mobileButtonParent: {
    height: 256,
    width: 274,
  },
  signupButtonChild: {
    borderRadius: Border.br_8xs,
    backgroundColor: Color.tomato_100,
  },
  create: {
    top: 7,
    left: 99,
    fontSize: FontSize.size_xl,
    fontWeight: "700",
    fontFamily: FontFamily.poppins,
    color: Color.white,
    textAlign: "left",
    position: "absolute",
  },
  signupButton: {
    top: 194,
    left: 14,
  },
  listItems: {
    alignSelf: "stretch",
  },
  searchResultsBody: {
    width: 375,
    maxWidth: 375,
    flex: 1,
  },
  searchResults: {
    backgroundColor: Color.studioLightmodeLightBGF8F9FB,
    width: "100%",
    flex: 1,
  },
});

export default SearchResults1;
