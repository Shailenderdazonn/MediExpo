import * as React from "react";
import { StyleSheet, View, Text, Image } from "react-native";
import { Border, Color, FontSize, FontFamily } from "../GlobalStyles";

const PatientSignup2 = () => {
  return (
    <View style={styles.patientSignup2}>
      <View style={styles.patientSignup2Child} />
      <View style={[styles.servicesRequiredButton, styles.servicesLayout]}>
        <View
          style={[styles.servicesRequiredButtonChild, styles.servicesLayout]}
        />
        <Text style={[styles.servicesRequired, styles.createFlexBox]}>
          Services Required
        </Text>
        <Image
          style={styles.vectorIcon}
          resizeMode="cover"
          source={require("../assets/vector2.png")}
        />
      </View>
      <View style={[styles.signupButton, styles.signupLayout]}>
        <View style={[styles.signupButtonChild, styles.signupLayout]} />
        <Text style={[styles.create, styles.createFlexBox]}>Create</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  servicesLayout: {
    width: 274,
    position: "absolute",
  },
  createFlexBox: {
    textAlign: "left",
    position: "absolute",
  },
  signupLayout: {
    height: 37,
    width: 274,
    position: "absolute",
  },
  patientSignup2Child: {
    top: 32,
    left: 23,
    borderRadius: Border.br_11xl,
    backgroundColor: Color.whitesmoke_400,
    width: 321,
    height: 724,
    position: "absolute",
  },
  servicesRequiredButtonChild: {
    top: 24,
    backgroundColor: Color.gray_100,
    height: 2,
    left: 0,
  },
  servicesRequired: {
    left: 10,
    fontSize: FontSize.size_sm,
    fontFamily: FontFamily.lato,
    color: Color.gray_100,
    top: 0,
  },
  vectorIcon: {
    height: "26.92%",
    width: "3.65%",
    top: "23.08%",
    right: "6.2%",
    bottom: "50%",
    left: "90.15%",
    maxWidth: "100%",
    overflow: "hidden",
    maxHeight: "100%",
    position: "absolute",
  },
  servicesRequiredButton: {
    top: 88,
    height: 26,
    left: 42,
  },
  signupButtonChild: {
    borderRadius: Border.br_8xs,
    backgroundColor: Color.tomato_100,
    top: 0,
    left: 0,
  },
  create: {
    top: 7,
    left: 99,
    fontSize: FontSize.size_xl,
    fontWeight: "700",
    fontFamily: FontFamily.poppins,
    color: Color.white,
  },
  signupButton: {
    top: 178,
    left: 42,
  },
  patientSignup2: {
    borderRadius: Border.br_21xl,
    backgroundColor: Color.whitesmoke_300,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    flex: 1,
    width: "100%",
    height: 792,
  },
});

export default PatientSignup2;
