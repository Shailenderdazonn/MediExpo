import * as React from "react";
import { Image, StyleSheet, View, Text } from "react-native";
import { Border, Color, FontSize, FontFamily } from "../GlobalStyles";

const PatientForm = () => {
  return (
    <View style={styles.patientForm}>
      <Image
        style={styles.patientFormChild}
        resizeMode="cover"
        source={require("../assets/rectangle-44.png")}
      />
      <View style={[styles.booknowGroup, styles.booknowGroupLayout]}>
        <View style={[styles.booknowGroupChild, styles.booknowGroupLayout]} />
        <Text style={[styles.bookNow, styles.bookNowFlexBox]}>Book Now</Text>
      </View>
      <View
        style={[
          styles.specializationGroup,
          styles.groupLayout,
          styles.groupPosition,
        ]}
      >
        <View style={[styles.specializationButton, styles.groupLayout]}>
          <View style={styles.specializationButtonChild} />
          <Text style={[styles.specialization, styles.bookNowFlexBox]}>
            Specialization
          </Text>
        </View>
      </View>
      <View
        style={[
          styles.specializationGroup1,
          styles.groupLayout,
          styles.groupPosition,
        ]}
      >
        <View style={[styles.specializationButton, styles.groupLayout]}>
          <View style={styles.specializationButtonChild} />
          <Text style={[styles.specialization, styles.bookNowFlexBox]}>
            Available
          </Text>
        </View>
      </View>
      <View
        style={[styles.nameGroup, styles.groupLayout, styles.groupPosition]}
      >
        <View style={[styles.specializationButton, styles.groupLayout]}>
          <View style={styles.specializationButtonChild} />
          <Text style={[styles.specialization, styles.bookNowFlexBox]}>
            Full Name
          </Text>
        </View>
      </View>
      <Image
        style={styles.uploadImageIcon}
        resizeMode="cover"
        source={require("../assets/upload-image.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  booknowGroupLayout: {
    height: 37,
    width: 274,
    position: "absolute",
  },
  bookNowFlexBox: {
    textAlign: "left",
    position: "absolute",
  },
  groupLayout: {
    height: 26,
    width: 274,
    position: "absolute",
  },
  groupPosition: {
    left: 35,
    height: 26,
  },
  patientFormChild: {
    top: 151,
    borderRadius: Border.br_11xl,
    width: 357,
    height: 641,
    left: 0,
    position: "absolute",
  },
  booknowGroupChild: {
    borderRadius: Border.br_8xs,
    backgroundColor: Color.tomato_100,
    top: 0,
    left: 0,
  },
  bookNow: {
    top: 7,
    left: 88,
    fontSize: FontSize.size_xl,
    fontWeight: "700",
    fontFamily: FontFamily.poppins,
    color: Color.white,
  },
  booknowGroup: {
    top: 538,
    left: 42,
  },
  specializationButtonChild: {
    top: 24,
    backgroundColor: Color.gray_100,
    height: 2,
    width: 274,
    left: 0,
    position: "absolute",
  },
  specialization: {
    left: 10,
    fontSize: FontSize.size_sm,
    fontFamily: FontFamily.lato,
    color: Color.gray_100,
    top: 0,
  },
  specializationButton: {
    top: 0,
    left: 0,
  },
  specializationGroup: {
    top: 357,
  },
  specializationGroup1: {
    top: 424,
  },
  nameGroup: {
    top: 290,
  },
  uploadImageIcon: {
    top: 81,
    left: 105,
    width: 147,
    height: 147,
    position: "absolute",
  },
  patientForm: {
    borderRadius: Border.br_21xl,
    backgroundColor: Color.teal_100,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    flex: 1,
    width: "100%",
    height: 792,
  },
});

export default PatientForm;
