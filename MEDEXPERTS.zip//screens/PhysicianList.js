import * as React from "react";
import { StyleSheet, View, Text, Image, Pressable } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { Border, Color, FontFamily, FontSize } from "../GlobalStyles";

const PhysicianList = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.chemist}>
      <View style={styles.searchMedical}>
        <View style={styles.searchMedicalChild} />
        <Text style={styles.searchChemist}>Search Chemist</Text>
        <Image
          style={styles.searchIcon}
          resizeMode="cover"
          source={require("../assets/search.png")}
        />
      </View>
      <View style={[styles.rectangleParent, styles.rectangleLayout]}>
        <View style={[styles.groupChild, styles.groupLayout]} />
        <Text
          style={[styles.medicalStores, styles.labTestClr, styles.labTestTypo]}
        >
          Medical Stores
        </Text>
        <Image
          style={[styles.medicalStores1Icon, styles.iconLayout]}
          resizeMode="cover"
          source={require("../assets/medicalstores-1.png")}
        />
      </View>
      <View style={[styles.rectangleGroup, styles.rectangleLayout]}>
        <View style={[styles.groupItem, styles.groupLayout]} />
        <Text
          style={[styles.labPosition, styles.labTestClr, styles.labTestTypo]}
        >
          Lab Test
        </Text>
        <Image
          style={[styles.labTest1Icon, styles.labPosition, styles.iconLayout]}
          resizeMode="cover"
          source={require("../assets/labtest-1.png")}
        />
      </View>
      <View style={styles.adminPosition}>
        <View style={[styles.adminChild, styles.adminPosition]} />
        <Text
          style={[styles.chemist1, styles.chemist1Position, styles.labTestClr]}
        >
          Chemist
        </Text>
        <Pressable
          style={[styles.arrowLeft1, styles.chemist1Position]}
          onPress={() => navigation.navigate("CategoriesList")}
        >
          <Image
            style={styles.icon}
            resizeMode="cover"
            source={require("../assets/arrowleft-1.png")}
          />
        </Pressable>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  rectangleLayout: {
    height: 120,
    width: 144,
    top: 259,
    position: "absolute",
  },
  groupLayout: {
    borderRadius: Border.br_mini,
    height: 120,
    width: 144,
    left: 0,
    top: 0,
    position: "absolute",
  },
  labTestClr: {
    color: Color.lightLabelPrimary,
    textAlign: "left",
  },
  labTestTypo: {
    fontFamily: FontFamily.latoMedium,
    fontWeight: "500",
    fontSize: FontSize.size_sm,
    top: 97,
    color: Color.lightLabelPrimary,
  },
  iconLayout: {
    height: 57,
    top: 12,
  },
  labPosition: {
    left: 47,
    position: "absolute",
  },
  adminPosition: {
    height: 88,
    width: 357,
    left: 0,
    top: 0,
    position: "absolute",
  },
  chemist1Position: {
    top: 50,
    position: "absolute",
  },
  searchMedicalChild: {
    borderRadius: Border.br_xs,
    backgroundColor: Color.whitesmoke_200,
    borderStyle: "solid",
    borderColor: "#0f6d65",
    borderWidth: 1,
    left: 0,
    top: 0,
    height: 61,
    width: 304,
    position: "absolute",
  },
  searchChemist: {
    top: 22,
    left: 45,
    fontSize: FontSize.size_xs,
    fontFamily: FontFamily.latoRegular,
    color: Color.darkgray,
    width: 107,
    height: 17,
    textAlign: "left",
    position: "absolute",
  },
  searchIcon: {
    top: 19,
    left: 22,
    width: 20,
    height: 22,
    position: "absolute",
  },
  searchMedical: {
    top: 146,
    height: 61,
    width: 304,
    left: 27,
    position: "absolute",
  },
  groupChild: {
    backgroundColor: Color.forestgreen,
  },
  medicalStores: {
    left: 27,
    fontWeight: "500",
    fontSize: FontSize.size_sm,
    top: 97,
    position: "absolute",
  },
  medicalStores1Icon: {
    left: 42,
    width: 61,
    position: "absolute",
  },
  rectangleParent: {
    left: 184,
  },
  groupItem: {
    backgroundColor: Color.darksalmon,
  },
  labTest1Icon: {
    width: 56,
  },
  rectangleGroup: {
    left: 30,
  },
  adminChild: {
    borderTopLeftRadius: Border.br_23xl,
    borderTopRightRadius: Border.br_23xl,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    backgroundColor: Color.white,
  },
  chemist1: {
    left: 54,
    fontSize: FontSize.size_lg,
    fontWeight: "800",
    fontFamily: FontFamily.latoExtrabold,
    width: 111,
    height: 20,
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  arrowLeft1: {
    left: 24,
    width: 24,
    height: 23,
  },
  chemist: {
    borderRadius: Border.br_21xl,
    flex: 1,
    height: 792,
    width: "100%",
    backgroundColor: Color.white,
  },
});

export default PhysicianList;
