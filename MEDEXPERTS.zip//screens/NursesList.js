import * as React from "react";
import { StyleSheet, View, Text, Image } from "react-native";
import { Border, FontFamily, FontSize, Color } from "../GlobalStyles";

const NursesList = () => {
  return (
    <View style={styles.nursesList2}>
      <View style={styles.searchMedical}>
        <View style={styles.searchMedicalChild} />
        <Text style={styles.searchNurse}>Search Nurse</Text>
        <Image
          style={styles.searchIcon}
          resizeMode="cover"
          source={require("../assets/search.png")}
        />
      </View>
      <View style={styles.adminPosition}>
        <View style={[styles.adminChild, styles.adminPosition]} />
        <Text style={styles.nurseList2}>Nurse List-2</Text>
        <Image
          style={styles.arrowLeft1Icon}
          resizeMode="cover"
          source={require("../assets/arrowleft-1.png")}
        />
      </View>
      <View style={[styles.nursesList2Inner, styles.groupParentLayout]}>
        <View style={[styles.groupParent, styles.groupParentLayout]}>
          <View style={[styles.rectangleParent, styles.rectangleLayout]}>
            <View style={[styles.groupChild, styles.groupLayout]} />
            <Text
              style={[styles.licensedPracticalNurse, styles.nurseTypo2]}
            >{`Licensed Practical
Nurse (LPN)`}</Text>
          </View>
          <View style={[styles.rectangleGroup, styles.rectangleLayout]}>
            <View style={[styles.groupItem, styles.groupLayout]} />
            <Text
              style={[
                styles.certifiedNursingAssistant,
                styles.homeCareRegisteredTypo,
              ]}
            >{`Certified Nursing
Assistant (CNA)`}</Text>
          </View>
          <View style={[styles.rectangleContainer, styles.groupViewPosition]}>
            <View style={[styles.groupInner, styles.groupLayout]} />
            <Text
              style={[styles.surgicalAssistantRegistered, styles.nurseTypo2]}
            >{`Surgical Assistant
Registered Nurse`}</Text>
          </View>
          <View style={[styles.groupView, styles.groupViewPosition]}>
            <View style={[styles.rectangleView, styles.groupLayout]} />
            <Text
              style={[
                styles.certifiedNursingAssistant,
                styles.homeCareRegisteredTypo,
              ]}
            >{`Registered Nurse
(RN)`}</Text>
          </View>
          <View
            style={[styles.rectangleParent1, styles.rectangleParentPosition5]}
          >
            <View style={[styles.groupChild, styles.groupLayout]} />
            <Text
              style={[styles.surgicalAssistantRegistered, styles.nurseTypo2]}
            >{`Emergency Room
Registered Nurse`}</Text>
          </View>
          <View
            style={[styles.rectangleParent2, styles.rectangleParentPosition5]}
          >
            <View style={[styles.groupItem, styles.groupLayout]} />
            <Text
              style={[styles.homeCareRegistered, styles.homeCareRegisteredTypo]}
            >{`Home Care
Registered Nurse`}</Text>
          </View>
          <View
            style={[styles.rectangleParent3, styles.rectangleParentPosition4]}
          >
            <View style={[styles.groupInner, styles.groupLayout]} />
            <Text
              style={[styles.clinicalNurseSupervisor, styles.nurseTypo2]}
            >{`Clinical Nurse
Supervisor`}</Text>
          </View>
          <View
            style={[styles.rectangleParent4, styles.rectangleParentPosition4]}
          >
            <View style={[styles.rectangleView, styles.groupLayout]} />
            <Text
              style={[styles.laborDelivery, styles.nurseTypo2]}
            >{`Labor & Delivery
Nurse`}</Text>
          </View>
          <View
            style={[styles.rectangleParent5, styles.rectangleParentPosition3]}
          >
            <View style={[styles.groupChild, styles.groupLayout]} />
            <Text
              style={[styles.surgicalAssistantRegistered, styles.nurseTypo2]}
            >{`Critical Care
Registered Nurse`}</Text>
          </View>
          <View
            style={[styles.rectangleParent6, styles.rectangleParentPosition3]}
          >
            <View style={[styles.groupItem, styles.groupLayout]} />
            <Text style={[styles.nurseCaseManager, styles.nurseTypo1]}>
              Nurse Case Manager
            </Text>
          </View>
          <View
            style={[styles.rectangleParent7, styles.rectangleParentPosition2]}
          >
            <View style={[styles.groupInner, styles.groupLayout]} />
            <Text
              style={[styles.healthInformaticsNurse, styles.nurseTypo]}
            >{`Health Informatics
Nurse Specialist`}</Text>
          </View>
          <View
            style={[styles.rectangleParent8, styles.rectangleParentPosition2]}
          >
            <View style={[styles.rectangleView, styles.groupLayout]} />
            <Text
              style={[styles.oncologyRegisteredNurse, styles.nurseTypo1]}
            >{`Oncology Registered
Nurse`}</Text>
          </View>
          <View
            style={[styles.rectangleParent9, styles.rectangleParentPosition1]}
          >
            <View style={[styles.groupChild, styles.groupLayout]} />
            <Text
              style={[styles.clinicalNurseSpecialist, styles.nurseTypo2]}
            >{`Clinical Nurse
Specialist`}</Text>
          </View>
          <View
            style={[styles.rectangleParent10, styles.rectangleParentPosition1]}
          >
            <View style={[styles.groupItem, styles.groupLayout]} />
            <Text
              style={[styles.healthInformaticsNurse, styles.nurseTypo]}
            >{`Advanced Practice
Registered Nurse`}</Text>
          </View>
          <View
            style={[styles.rectangleParent11, styles.rectangleParentPosition]}
          >
            <View style={[styles.groupInner, styles.groupLayout]} />
            <Text style={[styles.nurseEducator, styles.nurseTypo2]}>
              Nurse Educator
            </Text>
          </View>
          <View
            style={[styles.rectangleParent12, styles.rectangleParentPosition]}
          >
            <View style={[styles.rectangleView, styles.groupLayout]} />
            <Text style={[styles.nursePractitioner, styles.nurseTypo]}>
              Nurse Practitioner
            </Text>
          </View>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  adminPosition: {
    height: 88,
    width: 357,
    left: 0,
    top: 0,
    position: "absolute",
  },
  groupParentLayout: {
    width: 298,
    position: "absolute",
  },
  rectangleLayout: {
    height: 120,
    width: 144,
    top: 0,
    position: "absolute",
  },
  groupLayout: {
    borderRadius: Border.br_mini,
    height: 120,
    width: 144,
    left: 0,
    top: 0,
    position: "absolute",
  },
  nurseTypo2: {
    textAlign: "center",
    fontFamily: FontFamily.latoMedium,
    fontWeight: "500",
    fontSize: FontSize.size_sm,
    color: Color.lightLabelPrimary,
    position: "absolute",
  },
  homeCareRegisteredTypo: {
    left: 19,
    textAlign: "center",
    fontFamily: FontFamily.latoMedium,
    fontWeight: "500",
    fontSize: FontSize.size_sm,
    color: Color.lightLabelPrimary,
    position: "absolute",
  },
  groupViewPosition: {
    top: 130,
    height: 120,
    width: 144,
    position: "absolute",
  },
  rectangleParentPosition5: {
    top: 260,
    height: 120,
    width: 144,
    position: "absolute",
  },
  rectangleParentPosition4: {
    top: 390,
    height: 120,
    width: 144,
    position: "absolute",
  },
  rectangleParentPosition3: {
    top: 520,
    height: 120,
    width: 144,
    position: "absolute",
  },
  nurseTypo1: {
    left: 8,
    textAlign: "center",
    fontFamily: FontFamily.latoMedium,
    fontWeight: "500",
    fontSize: FontSize.size_sm,
    color: Color.lightLabelPrimary,
    position: "absolute",
  },
  rectangleParentPosition2: {
    top: 650,
    height: 120,
    width: 144,
    position: "absolute",
  },
  nurseTypo: {
    left: 15,
    textAlign: "center",
    fontFamily: FontFamily.latoMedium,
    fontWeight: "500",
    fontSize: FontSize.size_sm,
    color: Color.lightLabelPrimary,
    position: "absolute",
  },
  rectangleParentPosition1: {
    top: 780,
    height: 120,
    width: 144,
    position: "absolute",
  },
  rectangleParentPosition: {
    top: 910,
    height: 120,
    width: 144,
    position: "absolute",
  },
  searchMedicalChild: {
    borderRadius: Border.br_xs,
    backgroundColor: Color.whitesmoke_200,
    borderStyle: "solid",
    borderColor: "#0f6d65",
    borderWidth: 1,
    left: 0,
    top: 0,
    height: 61,
    width: 304,
    position: "absolute",
  },
  searchNurse: {
    top: 22,
    left: 45,
    fontSize: FontSize.size_xs,
    fontFamily: FontFamily.latoRegular,
    color: Color.darkgray,
    width: 107,
    height: 17,
    textAlign: "left",
    position: "absolute",
  },
  searchIcon: {
    top: 19,
    left: 22,
    width: 20,
    height: 22,
    position: "absolute",
  },
  searchMedical: {
    top: 146,
    left: 27,
    height: 61,
    width: 304,
    position: "absolute",
  },
  adminChild: {
    borderTopLeftRadius: Border.br_23xl,
    borderTopRightRadius: Border.br_23xl,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    backgroundColor: Color.white,
  },
  nurseList2: {
    left: 54,
    fontSize: FontSize.size_lg,
    fontWeight: "800",
    fontFamily: FontFamily.latoExtrabold,
    width: 111,
    height: 20,
    color: Color.lightLabelPrimary,
    top: 48,
    textAlign: "left",
    position: "absolute",
  },
  arrowLeft1Icon: {
    width: 24,
    height: 23,
    left: 24,
    top: 48,
    position: "absolute",
  },
  groupChild: {
    backgroundColor: Color.forestgreen,
  },
  licensedPracticalNurse: {
    left: 17,
    top: 77,
  },
  rectangleParent: {
    left: 154,
  },
  groupItem: {
    backgroundColor: Color.darksalmon,
  },
  certifiedNursingAssistant: {
    top: 77,
  },
  rectangleGroup: {
    left: 0,
  },
  groupInner: {
    backgroundColor: Color.mistyrose,
  },
  surgicalAssistantRegistered: {
    left: 18,
    top: 79,
  },
  rectangleContainer: {
    left: 154,
  },
  rectangleView: {
    backgroundColor: Color.darkseagreen,
  },
  groupView: {
    left: 0,
  },
  rectangleParent1: {
    left: 154,
  },
  homeCareRegistered: {
    top: 79,
  },
  rectangleParent2: {
    left: 0,
  },
  clinicalNurseSupervisor: {
    top: 79,
    left: 30,
  },
  rectangleParent3: {
    left: 154,
  },
  laborDelivery: {
    left: 20,
    top: 79,
  },
  rectangleParent4: {
    left: 0,
  },
  rectangleParent5: {
    left: 154,
  },
  nurseCaseManager: {
    top: 96,
  },
  rectangleParent6: {
    left: 0,
  },
  healthInformaticsNurse: {
    top: 79,
  },
  rectangleParent7: {
    left: 154,
  },
  oncologyRegisteredNurse: {
    top: 79,
  },
  rectangleParent8: {
    left: 0,
  },
  clinicalNurseSpecialist: {
    left: 29,
    top: 79,
  },
  rectangleParent9: {
    left: 154,
  },
  rectangleParent10: {
    left: 0,
  },
  nurseEducator: {
    top: 96,
    left: 24,
  },
  rectangleParent11: {
    left: 154,
  },
  nursePractitioner: {
    top: 96,
  },
  rectangleParent12: {
    left: 0,
  },
  groupParent: {
    top: 2,
    height: 1030,
    left: 0,
  },
  nursesList2Inner: {
    top: 256,
    height: 510,
    left: 30,
  },
  nursesList2: {
    borderRadius: Border.br_21xl,
    flex: 1,
    width: "100%",
    height: 792,
    backgroundColor: Color.white,
  },
});

export default NursesList;
