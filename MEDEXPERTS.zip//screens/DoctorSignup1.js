import * as React from "react";
import { StyleSheet, View, Text, Image } from "react-native";
import { Color, FontFamily, FontSize, Border } from "../GlobalStyles";

const DoctorSignup1 = () => {
  return (
    <View style={styles.doctorSignup}>
      <View style={styles.doctorSignupChild} />
      <View style={[styles.chooseSelf, styles.buttonLayout]}>
        <View style={styles.chooseSelfChild} />
        <Text style={[styles.chooseSelf1, styles.maleTypo]}>Choose Self</Text>
        <Image
          style={styles.vectorIcon}
          resizeMode="cover"
          source={require("../assets/vector2.png")}
        />
      </View>
      <View style={[styles.specializationButton, styles.buttonLayout]}>
        <View style={styles.chooseSelfChild} />
        <Text style={[styles.chooseSelf1, styles.maleTypo]}>
          Specialization
        </Text>
        <Image
          style={styles.vectorIcon}
          resizeMode="cover"
          source={require("../assets/vector2.png")}
        />
      </View>
      <View style={[styles.pincodeButton, styles.buttonLayout]}>
        <View style={styles.chooseSelfChild} />
        <Text style={[styles.chooseSelf1, styles.maleTypo]}>Pin Code</Text>
      </View>
      <View style={[styles.stateButton, styles.buttonLayout]}>
        <View style={styles.chooseSelfChild} />
        <Text style={[styles.chooseSelf1, styles.maleTypo]}>State</Text>
        <Image
          style={styles.vectorIcon}
          resizeMode="cover"
          source={require("../assets/vector2.png")}
        />
      </View>
      <View style={[styles.cityButton, styles.buttonLayout]}>
        <View style={styles.chooseSelfChild} />
        <Image
          style={styles.vectorIcon}
          resizeMode="cover"
          source={require("../assets/vector2.png")}
        />
        <Text style={[styles.chooseSelf1, styles.maleTypo]}>City</Text>
      </View>
      <View style={[styles.addressButton, styles.buttonLayout]}>
        <View style={styles.chooseSelfChild} />
        <Text style={[styles.chooseSelf1, styles.maleTypo]}>Address</Text>
      </View>
      <View style={[styles.ageButton, styles.buttonLayout]}>
        <View style={styles.chooseSelfChild} />
        <Text style={[styles.chooseSelf1, styles.maleTypo]}>Age</Text>
      </View>
      <View style={[styles.genderButton, styles.buttonLayout]}>
        <View style={styles.chooseSelfChild} />
        <Text style={[styles.female, styles.maleTypo]}>Female</Text>
        <Image
          style={[styles.genderButtonItem, styles.genderLayout]}
          resizeMode="cover"
          source={require("../assets/ellipse-7.png")}
        />
        <Text style={[styles.male, styles.maleTypo]}>Male</Text>
        <Image
          style={[styles.genderButtonInner, styles.genderLayout]}
          resizeMode="cover"
          source={require("../assets/ellipse-7.png")}
        />
        <Text style={[styles.chooseSelf1, styles.maleTypo]}>Gender</Text>
      </View>
      <View style={[styles.mobileButton, styles.buttonLayout]}>
        <View style={styles.chooseSelfChild} />
        <Text style={[styles.chooseSelf1, styles.maleTypo]}>Mobile Number</Text>
      </View>
      <View style={[styles.nameButton, styles.buttonLayout]}>
        <View style={styles.chooseSelfChild} />
        <Text style={[styles.chooseSelf1, styles.maleTypo]}>Full Name</Text>
      </View>
      <View style={styles.loginText}>
        <Text style={[styles.signUp, styles.signUpTypo]}>{`Sign Up `}</Text>
      </View>
      <View style={[styles.signupButton, styles.signupLayout]}>
        <View style={[styles.signupButtonChild, styles.signupLayout]} />
        <Text style={[styles.create, styles.signUpTypo]}>Create</Text>
      </View>
      <View style={[styles.logo, styles.logoLayout]}>
        <Image
          style={[styles.image2Icon, styles.logoLayout]}
          resizeMode="cover"
          source={require("../assets/image-22.png")}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  buttonLayout: {
    height: 26,
    width: 274,
    left: 42,
    position: "absolute",
  },
  maleTypo: {
    textAlign: "left",
    color: Color.gray_100,
    fontFamily: FontFamily.lato,
    fontSize: FontSize.size_sm,
    top: 0,
    position: "absolute",
  },
  genderLayout: {
    height: 12,
    width: 12,
    top: 2,
    position: "absolute",
  },
  signUpTypo: {
    fontFamily: FontFamily.poppins,
    fontWeight: "700",
    fontSize: FontSize.size_xl,
    textAlign: "left",
    position: "absolute",
  },
  signupLayout: {
    height: 37,
    width: 274,
    position: "absolute",
  },
  logoLayout: {
    height: 52,
    width: 109,
    position: "absolute",
  },
  doctorSignupChild: {
    top: 32,
    left: 23,
    borderRadius: Border.br_11xl,
    backgroundColor: Color.whitesmoke_400,
    width: 321,
    height: 724,
    position: "absolute",
  },
  chooseSelfChild: {
    top: 24,
    backgroundColor: Color.gray_100,
    height: 2,
    left: 0,
    width: 274,
    position: "absolute",
  },
  chooseSelf1: {
    left: 10,
  },
  vectorIcon: {
    height: "26.92%",
    width: "3.65%",
    top: "23.08%",
    right: "6.2%",
    bottom: "50%",
    left: "90.15%",
    maxWidth: "100%",
    overflow: "hidden",
    maxHeight: "100%",
    position: "absolute",
  },
  chooseSelf: {
    top: 646,
  },
  specializationButton: {
    top: 594,
  },
  pincodeButton: {
    top: 544,
  },
  stateButton: {
    top: 494,
  },
  cityButton: {
    top: 444,
  },
  addressButton: {
    top: 394,
  },
  ageButton: {
    top: 344,
  },
  female: {
    left: 210,
  },
  genderButtonItem: {
    left: 194,
  },
  male: {
    left: 140,
  },
  genderButtonInner: {
    left: 123,
  },
  genderButton: {
    top: 294,
  },
  mobileButton: {
    top: 244,
  },
  nameButton: {
    top: 194,
  },
  signUp: {
    left: -10,
    color: Color.darkslateblue,
    top: 0,
  },
  loginText: {
    top: 148,
    left: 151,
    width: 55,
    height: 23,
    position: "absolute",
  },
  signupButtonChild: {
    borderRadius: Border.br_8xs,
    backgroundColor: Color.tomato_100,
    top: 0,
    left: 0,
  },
  create: {
    top: 7,
    left: 99,
    color: Color.white,
  },
  signupButton: {
    top: 698,
    left: 42,
    height: 37,
  },
  image2Icon: {
    top: 0,
    left: 0,
  },
  logo: {
    top: 64,
    left: 124,
  },
  doctorSignup: {
    borderRadius: Border.br_21xl,
    backgroundColor: Color.whitesmoke_300,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    flex: 1,
    width: "100%",
    height: 792,
  },
});

export default DoctorSignup1;
