import * as React from "react";
import { Text, StyleSheet, View, Image, Pressable } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { useNavigation } from "@react-navigation/native";
import { Color, FontSize, FontFamily, Border } from "../GlobalStyles";

const CategoriesList = () => {
  const navigation = useNavigation();

  return (
    <View style={[styles.categoriesList, styles.categoriesShadowBox]}>
      <View style={styles.upcomingAppointments}>
        <Text style={[styles.upcomingAppointments1, styles.categoriesTypo]}>
          Upcoming Appointments
        </Text>
        <View style={styles.upcomingAppointmentsChild} />
        <View style={[styles.upcomingAppointmentsItem, styles.itemBg]} />
        <Text style={[styles.tue, styles.tueLayout, styles.tueTypo]}>{`  12
Tue`}</Text>
        <Text style={styles.amDrMimContainer}>
          <Text style={styles.amDrMimAnkhtr}>
            <Text>{`09:30 AM

`}</Text>
            <Text style={styles.drMimAnkhtr}>{`Dr. Mim Ankhtr

`}</Text>
          </Text>
          <Text style={styles.depression}>Depression</Text>
        </Text>
        <Image
          style={styles.moreIcon}
          resizeMode="cover"
          source={require("../assets/more.png")}
        />
      </View>
      <View
        style={[
          styles.rectangleParent,
          styles.groupChildLayout,
          styles.rectangleParentPosition,
        ]}
      >
        <LinearGradient
          style={[
            styles.groupChild,
            styles.groupChildLayout,
            styles.groupChildPosition,
          ]}
          locations={[0, 1]}
          colors={["rgba(72, 175, 198, 0.6)", "rgba(72, 175, 198, 0.25)"]}
        />
        <Image
          style={styles.untitled41Icon}
          resizeMode="cover"
          source={require("../assets/untitled4-1.png")}
        />
        <Image
          style={[
            styles.unsplashptrhfmj2jdaIcon,
            styles.groupChildLayout,
            styles.rectangleParentPosition,
          ]}
          resizeMode="cover"
          source={require("../assets/unsplashptrhfmj2jda.png")}
        />
        <Text
          style={[
            styles.bookAppointment,
            styles.image5IconPosition,
            styles.tueLayout,
            styles.helloTypo,
          ]}
        >
          Book Appointment
        </Text>
        <Text
          style={[
            styles.quicklyCreateFiles,
            styles.helloClr,
            styles.searchMedical1Typo,
          ]}
        >
          Quickly Create Files
        </Text>
        <View style={[styles.groupItem, styles.itemBg]} />
        <Pressable
          style={styles.bookAppointment1}
          onPress={() => navigation.navigate("AppointmentNow")}
        >
          <Text style={styles.bookAppointment2}>Book Appointment</Text>
        </Pressable>
      </View>
      <View style={[styles.categoriesLists, styles.adminPosition]}>
        <Pressable
          style={[
            styles.doctorGroup,
            styles.doctorGroupLayout,
            styles.groupPosition1,
          ]}
          onPress={() => navigation.navigate("Doctor")}
        >
          <View
            style={[
              styles.doctorGroupChild,
              styles.doctorGroupLayout,
              styles.groupChildPosition,
            ]}
          />
          <Text style={[styles.doctor, styles.nurseTypo]}>{`Doctor  `}</Text>
          <Image
            style={[styles.image5Icon, styles.image5IconPosition]}
            resizeMode="cover"
            source={require("../assets/image-5.png")}
          />
        </Pressable>
        <Pressable
          style={[
            styles.nursesGroup,
            styles.doctorGroupLayout,
            styles.groupPosition1,
          ]}
          onPress={() => navigation.navigate("Nurses")}
        >
          <View
            style={[
              styles.doctorGroupChild,
              styles.doctorGroupLayout,
              styles.groupChildPosition,
            ]}
          />
          <Text style={[styles.nurse, styles.nurseTypo]}>Nurse</Text>
          <Image
            style={[styles.stethoscope56284971Icon, styles.iconLayout]}
            resizeMode="cover"
            source={require("../assets/stethoscope5628497-1.png")}
          />
        </Pressable>
        <Pressable
          style={[styles.crechGroup, styles.groupPosition]}
          onPress={() => navigation.navigate("Creches")}
        >
          <View
            style={[
              styles.doctorGroupChild,
              styles.doctorGroupLayout,
              styles.groupChildPosition,
            ]}
          />
          <Text style={[styles.crech, styles.crechTypo]}>Crech</Text>
          <Image
            style={[styles.crechImgIcon, styles.wrapperLayout]}
            resizeMode="cover"
            source={require("../assets/crech-img.png")}
          />
        </Pressable>
        <Pressable
          style={[styles.physicianGroup, styles.groupPosition]}
          onPress={() => navigation.navigate("Chemist")}
        >
          <View
            style={[
              styles.doctorGroupChild,
              styles.doctorGroupLayout,
              styles.groupChildPosition,
            ]}
          />
          <Text style={[styles.chemist, styles.crechTypo]}>Chemist</Text>
          <Image
            style={[styles.chemistry3dRenderIconIllus, styles.iconLayout]}
            resizeMode="cover"
            source={require("../assets/chemistry3drendericonillustrationpng-1.png")}
          />
        </Pressable>
        <Text style={[styles.categories, styles.categoriesTypo]}>
          Categories
        </Text>
      </View>
      <View style={[styles.searchMedical, styles.searchLayout]}>
        <View
          style={[
            styles.searchMedicalChild,
            styles.searchLayout,
            styles.groupChildPosition,
          ]}
        />
        <Text style={[styles.searchMedical1, styles.searchMedical1Typo]}>
          Search Medical
        </Text>
        <Image
          style={[styles.searchIcon, styles.adminNamePosition]}
          resizeMode="cover"
          source={require("../assets/search.png")}
        />
      </View>
      <View
        style={[
          styles.categoriesListChild,
          styles.groupChildPosition,
          styles.categoriesShadowBox,
        ]}
      />
      <View style={[styles.admin, styles.adminPosition]}>
        <Pressable
          style={[styles.wrapper, styles.wrapperLayout]}
          onPress={() => navigation.navigate("Setting")}
        >
          <Image
            style={styles.icon}
            resizeMode="cover"
            source={require("../assets/ellipse-11.png")}
          />
        </Pressable>
        <Text
          style={[
            styles.adminName,
            styles.adminNamePosition,
            styles.helloClr,
            styles.tueTypo,
          ]}
        >
          Admin Name
        </Text>
        <Text
          style={[
            styles.hello,
            styles.helloClr,
            styles.helloTypo,
            styles.groupChildPosition,
          ]}
        >
          Hello
        </Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  categoriesShadowBox: {
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    backgroundColor: Color.white,
  },
  categoriesTypo: {
    color: Color.teal_100,
    fontSize: FontSize.size_base,
    left: 4,
    textAlign: "left",
    fontFamily: FontFamily.latoBold,
    fontWeight: "700",
    top: 0,
    position: "absolute",
  },
  itemBg: {
    backgroundColor: Color.tomato_100,
    position: "absolute",
  },
  tueLayout: {
    height: 40,
    textAlign: "left",
  },
  tueTypo: {
    fontWeight: "800",
    fontSize: FontSize.size_lg,
  },
  groupChildLayout: {
    height: 154,
    position: "absolute",
  },
  rectangleParentPosition: {
    top: 455,
    height: 154,
  },
  groupChildPosition: {
    top: 0,
    left: 0,
  },
  image5IconPosition: {
    top: 17,
    position: "absolute",
  },
  helloTypo: {
    fontFamily: FontFamily.latoBold,
    fontWeight: "700",
  },
  helloClr: {
    color: Color.lightLabelPrimary,
    textAlign: "left",
  },
  searchMedical1Typo: {
    fontSize: FontSize.size_xs,
    fontFamily: FontFamily.latoRegular,
    position: "absolute",
  },
  adminPosition: {
    width: 303,
    left: 27,
    position: "absolute",
  },
  doctorGroupLayout: {
    height: 77,
    width: 142,
    position: "absolute",
  },
  groupPosition1: {
    top: 27,
    width: 142,
  },
  nurseTypo: {
    textAlign: "center",
    fontFamily: FontFamily.latoMedium,
    top: 32,
    fontWeight: "500",
    color: Color.white,
    fontSize: FontSize.size_base,
    position: "absolute",
  },
  iconLayout: {
    height: 46,
    position: "absolute",
  },
  groupPosition: {
    top: 118,
    height: 77,
    width: 142,
    position: "absolute",
  },
  crechTypo: {
    top: 33,
    height: 20,
    textAlign: "center",
    fontFamily: FontFamily.latoMedium,
    fontWeight: "500",
    color: Color.white,
    fontSize: FontSize.size_base,
    position: "absolute",
  },
  wrapperLayout: {
    height: 35,
    width: 35,
    position: "absolute",
  },
  searchLayout: {
    height: 61,
    width: 304,
    position: "absolute",
  },
  adminNamePosition: {
    top: 19,
    position: "absolute",
  },
  upcomingAppointments1: {
    textAlign: "left",
  },
  upcomingAppointmentsChild: {
    top: 30,
    backgroundColor: "rgba(30, 107, 123, 0.89)",
    height: 108,
    borderRadius: Border.br_mini,
    left: 0,
    width: 304,
    position: "absolute",
  },
  upcomingAppointmentsItem: {
    top: 41,
    width: 78,
    height: 84,
    left: 18,
    borderRadius: Border.br_mini,
  },
  tue: {
    top: 63,
    left: 40,
    fontFamily: FontFamily.interExtrabold,
    color: Color.whitesmoke_200,
    width: 48,
    position: "absolute",
  },
  drMimAnkhtr: {
    fontSize: FontSize.size_mini,
    fontFamily: FontFamily.interMedium,
    fontWeight: "500",
  },
  amDrMimAnkhtr: {
    color: Color.white,
  },
  depression: {
    fontSize: FontSize.size_3xs,
    fontWeight: "600",
    fontFamily: FontFamily.interSemibold,
    color: "#ff3434",
  },
  amDrMimContainer: {
    top: 52,
    left: 120,
    letterSpacing: "-7.5%",
    width: 129,
    height: 76,
    textAlign: "left",
    position: "absolute",
  },
  moreIcon: {
    top: 35,
    left: 257,
    width: 25,
    height: 25,
    position: "absolute",
  },
  upcomingAppointments: {
    top: 629,
    height: 138,
    width: 304,
    left: 27,
    position: "absolute",
  },
  groupChild: {
    backgroundColor: "transparent",
    borderRadius: Border.br_mini,
    left: 0,
    width: 304,
  },
  untitled41Icon: {
    top: 14,
    left: 134,
    width: 168,
    height: 135,
    position: "absolute",
  },
  unsplashptrhfmj2jdaIcon: {
    left: 312,
    width: 125,
    display: "none",
  },
  bookAppointment: {
    fontSize: FontSize.size_xl,
    color: "#1c9679",
    width: 138,
    left: 18,
  },
  quicklyCreateFiles: {
    top: 70,
    fontFamily: FontFamily.latoRegular,
    left: 18,
  },
  groupItem: {
    top: 96,
    left: 21,
    borderRadius: 10,
    width: 82,
    height: 18,
  },
  bookAppointment2: {
    fontSize: 8,
    fontFamily: FontFamily.latoRegular,
    color: Color.white,
    textAlign: "left",
  },
  bookAppointment1: {
    left: 29,
    top: 100,
    position: "absolute",
  },
  rectangleParent: {
    width: 304,
    left: 27,
  },
  doctorGroupChild: {
    backgroundColor: Color.darkslateblue,
    borderRadius: Border.br_mini,
    left: 0,
  },
  doctor: {
    left: 54,
    width: 63,
    height: 25,
  },
  image5Icon: {
    width: 38,
    height: 44,
    left: 12,
  },
  doctorGroup: {
    left: 0,
  },
  nurse: {
    left: 70,
    width: 55,
    height: 20,
  },
  stethoscope56284971Icon: {
    top: 16,
    left: 8,
    width: 43,
  },
  nursesGroup: {
    left: 161,
  },
  crech: {
    left: 62,
    width: 66,
  },
  crechImgIcon: {
    top: 25,
    left: 11,
  },
  crechGroup: {
    left: 161,
  },
  chemist: {
    left: 60,
    width: 68,
  },
  chemistry3dRenderIconIllus: {
    top: 20,
    width: 46,
    left: 12,
  },
  physicianGroup: {
    left: 0,
  },
  categories: {
    width: 92,
    height: 22,
    textAlign: "left",
  },
  categoriesLists: {
    top: 231,
    height: 195,
  },
  searchMedicalChild: {
    borderRadius: Border.br_xs,
    backgroundColor: Color.whitesmoke_200,
    borderStyle: "solid",
    borderColor: "#0f6d65",
    borderWidth: 1,
    left: 0,
  },
  searchMedical1: {
    top: 22,
    left: 45,
    color: Color.darkgray,
    width: 107,
    height: 17,
    fontFamily: FontFamily.latoRegular,
    textAlign: "left",
  },
  searchIcon: {
    left: 22,
    width: 20,
    height: 22,
  },
  searchMedical: {
    top: 146,
    left: 27,
  },
  categoriesListChild: {
    borderTopLeftRadius: Border.br_23xl,
    borderTopRightRadius: Border.br_23xl,
    width: 357,
    height: 88,
    left: 0,
    position: "absolute",
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  wrapper: {
    left: 268,
    top: 7,
  },
  adminName: {
    fontFamily: FontFamily.latoExtrabold,
    width: 111,
    height: 20,
    left: 0,
  },
  hello: {
    fontSize: FontSize.size_sm,
    width: 75,
    height: 14,
    left: 0,
    position: "absolute",
  },
  admin: {
    top: 29,
    height: 42,
  },
  categoriesList: {
    borderRadius: Border.br_21xl,
    flex: 1,
    height: 792,
    width: "100%",
  },
});

export default CategoriesList;
