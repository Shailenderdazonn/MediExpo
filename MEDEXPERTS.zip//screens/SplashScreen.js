import * as React from "react";
import { Image, StyleSheet, View } from "react-native";
import { Border, Color } from "../GlobalStyles";

const SplashScreen = () => {
  return (
    <View style={styles.splashScreen}>
      <View style={styles.logo}>
        <Image
          style={styles.image2Icon}
          resizeMode="cover"
          source={require("../assets/image-2.png")}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  image2Icon: {
    alignSelf: "stretch",
    maxWidth: "100%",
    overflow: "hidden",
    height: 120,
    width: "100%",
  },
  logo: {
    position: "absolute",
    top: 579,
    left: 54,
    width: 250,
  },
  splashScreen: {
    borderRadius: Border.br_21xl,
    backgroundColor: Color.whitesmoke_300,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    flex: 1,
    height: 792,
    width: "100%",
  },
});

export default SplashScreen;
