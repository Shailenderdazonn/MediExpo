import * as React from "react";
import { StyleSheet, View, Text, Image } from "react-native";
import { Color, FontFamily, FontSize, Border } from "../GlobalStyles";

const Login = () => {
  return (
    <View style={styles.login}>
      <View style={styles.loginChild} />
      <View
        style={[
          styles.asPatientsButton,
          styles.buttonLayout,
          styles.buttonPosition,
        ]}
      >
        <View
          style={[
            styles.asPatientsButtonChild,
            styles.image2IconPosition,
            styles.buttonLayout,
          ]}
        />
        <Text style={[styles.loginAsPatient, styles.loginTypo]}>{`Login As
Patient`}</Text>
      </View>
      <View
        style={[
          styles.asDoctorButton,
          styles.buttonLayout,
          styles.buttonPosition,
        ]}
      >
        <View
          style={[
            styles.asPatientsButtonChild,
            styles.image2IconPosition,
            styles.buttonLayout,
          ]}
        />
        <Text style={[styles.loginAsDoctor, styles.loginTypo]}>{`Login
As
Doctor`}</Text>
      </View>
      <View style={[styles.logo, styles.logoLayout]}>
        <Image
          style={[styles.logoLayout, styles.image2IconPosition]}
          resizeMode="cover"
          source={require("../assets/image-2.png")}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  buttonLayout: {
    height: 101,
    width: 133,
    position: "absolute",
  },
  buttonPosition: {
    top: 399,
    width: 133,
  },
  image2IconPosition: {
    left: 0,
    top: 0,
  },
  loginTypo: {
    textAlign: "center",
    color: Color.white,
    fontFamily: FontFamily.poppins,
    fontWeight: "700",
    fontSize: FontSize.size_xl,
    left: 28,
    position: "absolute",
  },
  logoLayout: {
    height: 120,
    width: 250,
    position: "absolute",
  },
  loginChild: {
    top: 34,
    left: 18,
    borderRadius: Border.br_11xl,
    backgroundColor: Color.whitesmoke_400,
    width: 321,
    height: 724,
    position: "absolute",
  },
  asPatientsButtonChild: {
    borderRadius: Border.br_8xs,
    backgroundColor: Color.teal_100,
  },
  loginAsPatient: {
    top: 15,
    width: 81,
    height: 72,
  },
  asPatientsButton: {
    left: 42,
  },
  loginAsDoctor: {
    top: 19,
    width: 78,
    height: 64,
  },
  asDoctorButton: {
    left: 184,
  },
  logo: {
    top: 201,
    left: 45,
  },
  login: {
    borderRadius: Border.br_21xl,
    backgroundColor: Color.whitesmoke_300,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    flex: 1,
    width: "100%",
    height: 792,
  },
});

export default Login;
