import * as React from "react";
import { StyleSheet, View, Text, Image, Pressable } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { Border, FontFamily, FontSize, Color } from "../GlobalStyles";

const CrechesList = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.creches}>
      <View style={[styles.searchMedical, styles.searchLayout]}>
        <View style={[styles.searchMedicalChild, styles.searchLayout]} />
        <Text style={styles.searchCreches}>Search Creches</Text>
        <Image
          style={[styles.searchIcon, styles.iconPosition1]}
          resizeMode="cover"
          source={require("../assets/search.png")}
        />
      </View>
      <View style={[styles.crechesInner, styles.groupParentLayout]}>
        <View style={[styles.groupParent, styles.groupParentLayout]}>
          <View style={[styles.rectangleParent, styles.rectangleParentLayout]}>
            <View style={[styles.groupChild, styles.groupLayout]} />
            <Text
              style={[
                styles.privateOrStand,
                styles.homeTypo,
                styles.privateTypo,
              ]}
            >{`Private or Stand-
Alone Nurseries.`}</Text>
            <Image
              style={styles.sd1Icon}
              resizeMode="cover"
              source={require("../assets/sd-1.png")}
            />
          </View>
          <View style={[styles.rectangleGroup, styles.rectangleParentLayout]}>
            <View style={[styles.groupItem, styles.groupLayout]} />
            <Text
              style={[
                styles.privateDaycareChains,
                styles.homeTypo,
                styles.privateTypo,
              ]}
            >{`Private Daycare 
Chains`}</Text>
            <Image
              style={[styles.daycare11Icon, styles.daycare11Layout]}
              resizeMode="cover"
              source={require("../assets/daycare-1-1.png")}
            />
          </View>
          <View style={[styles.rectangleContainer, styles.groupViewPosition]}>
            <View style={[styles.groupInner, styles.groupLayout]} />
            <Text style={[styles.inHomeDaycare, styles.homeTypo]}>
              In Home Daycare
            </Text>
            <Image
              style={styles.inHomeDaycare1Icon}
              resizeMode="cover"
              source={require("../assets/inhomedaycare-1.png")}
            />
          </View>
          <View style={[styles.groupView, styles.groupViewPosition]}>
            <View style={[styles.rectangleView, styles.groupLayout]} />
            <Text
              style={[
                styles.homeBasedCreches,
                styles.homeTypo,
                styles.privateTypo,
              ]}
            >{`Home Based
Creches`}</Text>
            <Image
              style={[styles.teacherhome010111Icon, styles.iconPosition1]}
              resizeMode="cover"
              source={require("../assets/teacherhome01011-1.png")}
            />
          </View>
          <View
            style={[styles.rectangleParent1, styles.rectangleParentPosition3]}
          >
            <View style={[styles.groupChild, styles.groupLayout]} />
            <Text style={[styles.sharedNanny, styles.nannyTypo]}>
              Shared Nanny
            </Text>
            <Image
              style={[styles.sharedNanny1Icon, styles.iconPosition]}
              resizeMode="cover"
              source={require("../assets/sharednanny-1.png")}
            />
          </View>
          <View
            style={[styles.rectangleParent2, styles.rectangleParentPosition3]}
          >
            <View style={[styles.groupItem, styles.groupLayout]} />
            <Text style={[styles.nanny, styles.nannyTypo]}>Nanny</Text>
            <Image
              style={styles.nanny1Icon}
              resizeMode="cover"
              source={require("../assets/nanny-1.png")}
            />
          </View>
          <View
            style={[styles.rectangleParent3, styles.rectangleParentPosition2]}
          >
            <View style={[styles.groupInner, styles.groupLayout]} />
            <Text style={[styles.babysitter, styles.nannyTypo]}>
              Babysitter
            </Text>
            <Image
              style={styles.babysitter1Icon}
              resizeMode="cover"
              source={require("../assets/babysitter-1.png")}
            />
          </View>
          <View
            style={[styles.rectangleParent4, styles.rectangleParentPosition2]}
          >
            <View style={[styles.rectangleView, styles.groupLayout]} />
            <Text style={[styles.auPair, styles.nannyTypo]}>Au Pair</Text>
            <Image
              style={[styles.auPair1Icon, styles.iconLayout]}
              resizeMode="cover"
              source={require("../assets/aupair-1.png")}
            />
          </View>
          <View
            style={[styles.rectangleParent5, styles.rectangleParentPosition1]}
          >
            <View style={[styles.groupChild, styles.groupLayout]} />
            <Text style={[styles.relativeCare, styles.nannyTypo]}>
              Relative Care
            </Text>
            <Image
              style={styles.icon}
              resizeMode="cover"
              source={require("../assets/4024804-1.png")}
            />
          </View>
          <View
            style={[styles.rectangleParent6, styles.rectangleParentPosition1]}
          >
            <View style={[styles.groupItem, styles.groupLayout]} />
            <Text
              style={[
                styles.traditionalDaycareCenter,
                styles.homeTypo,
                styles.privateTypo,
              ]}
            >{`Traditional Daycare
Center`}</Text>
            <View style={[styles.daycare11, styles.daycare11Layout]} />
            <Image
              style={styles.baby526658644038601Icon}
              resizeMode="cover"
              source={require("../assets/baby52665864403860-1.png")}
            />
          </View>
          <View
            style={[styles.rectangleParent7, styles.rectangleParentPosition]}
          >
            <View style={[styles.groupInner, styles.groupLayout]} />
            <Text style={[styles.workplaceCreches, styles.nannyTypo]}>
              Workplace Creches
            </Text>
            <Image
              style={[styles.workplaceCreches1Icon, styles.iconLayout]}
              resizeMode="cover"
              source={require("../assets/workplacecreches-1.png")}
            />
          </View>
          <View
            style={[styles.rectangleParent8, styles.rectangleParentPosition]}
          >
            <View style={[styles.rectangleView, styles.groupLayout]} />
            <Text style={[styles.preschool, styles.nannyTypo]}>Preschool</Text>
            <Image
              style={styles.zeroNumber486364540562911Icon}
              resizeMode="cover"
              source={require("../assets/zeronumber48636454056291-1.png")}
            />
          </View>
          <View style={[styles.rectangleParent9, styles.rectangleParentLayout]}>
            <View style={[styles.groupItem, styles.groupLayout]} />
            <Text
              style={[styles.daycareCentresAttached, styles.homeTypo]}
            >{`Daycare Centres
Attached To 
Independent Schools`}</Text>
            <Image
              style={[
                styles.daycareCentresAttachedToInIcon,
                styles.iconPosition,
              ]}
              resizeMode="cover"
              source={require("../assets/daycarecentresattachedtoindependentchools-1.png")}
            />
          </View>
        </View>
      </View>
      <View style={styles.adminPosition}>
        <View style={[styles.adminChild, styles.adminPosition]} />
        <Text style={[styles.creches1, styles.creches1Position]}>Creches</Text>
        <Pressable
          style={[styles.arrowLeft1, styles.creches1Position]}
          onPress={() => navigation.navigate("CategoriesList")}
        >
          <Image
            style={styles.icon1}
            resizeMode="cover"
            source={require("../assets/arrowleft-1.png")}
          />
        </Pressable>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  searchLayout: {
    height: 61,
    width: 304,
    position: "absolute",
  },
  iconPosition1: {
    top: 19,
    position: "absolute",
  },
  groupParentLayout: {
    width: 298,
    position: "absolute",
  },
  rectangleParentLayout: {
    height: 120,
    width: 144,
    position: "absolute",
  },
  groupLayout: {
    borderRadius: Border.br_mini,
    height: 120,
    width: 144,
    left: 0,
    top: 0,
    position: "absolute",
  },
  homeTypo: {
    textAlign: "center",
    fontFamily: FontFamily.latoMedium,
    fontWeight: "500",
    fontSize: FontSize.size_sm,
    color: Color.lightLabelPrimary,
    position: "absolute",
  },
  privateTypo: {
    top: 79,
    fontFamily: FontFamily.latoMedium,
    fontWeight: "500",
    fontSize: FontSize.size_sm,
  },
  daycare11Layout: {
    height: 57,
    width: 57,
    left: 44,
    position: "absolute",
  },
  groupViewPosition: {
    top: 130,
    height: 120,
    width: 144,
    position: "absolute",
  },
  rectangleParentPosition3: {
    top: 260,
    height: 120,
    width: 144,
    position: "absolute",
  },
  nannyTypo: {
    top: 96,
    textAlign: "center",
    color: Color.lightLabelPrimary,
    fontFamily: FontFamily.latoMedium,
    fontWeight: "500",
    fontSize: FontSize.size_sm,
    position: "absolute",
  },
  iconPosition: {
    left: 48,
    position: "absolute",
  },
  rectangleParentPosition2: {
    top: 390,
    height: 120,
    width: 144,
    position: "absolute",
  },
  iconLayout: {
    width: 87,
    position: "absolute",
  },
  rectangleParentPosition1: {
    top: 520,
    height: 120,
    width: 144,
    position: "absolute",
  },
  rectangleParentPosition: {
    top: 650,
    height: 120,
    width: 144,
    position: "absolute",
  },
  adminPosition: {
    height: 88,
    width: 357,
    left: 0,
    top: 0,
    position: "absolute",
  },
  creches1Position: {
    top: 49,
    position: "absolute",
  },
  searchMedicalChild: {
    borderRadius: Border.br_xs,
    backgroundColor: Color.whitesmoke_200,
    borderStyle: "solid",
    borderColor: "#0f6d65",
    borderWidth: 1,
    left: 0,
    top: 0,
  },
  searchCreches: {
    left: 45,
    fontSize: FontSize.size_xs,
    fontFamily: FontFamily.latoRegular,
    color: Color.darkgray,
    width: 107,
    height: 17,
    textAlign: "left",
    top: 22,
    position: "absolute",
  },
  searchIcon: {
    width: 20,
    height: 22,
    left: 22,
  },
  searchMedical: {
    top: 146,
    left: 27,
  },
  groupChild: {
    backgroundColor: Color.forestgreen,
  },
  privateOrStand: {
    left: 20,
  },
  sd1Icon: {
    width: 41,
    height: 48,
    left: 50,
    top: 22,
    position: "absolute",
  },
  rectangleParent: {
    left: 154,
    top: 0,
  },
  groupItem: {
    backgroundColor: Color.darksalmon,
  },
  privateDaycareChains: {
    left: 22,
  },
  daycare11Icon: {
    top: 22,
  },
  rectangleGroup: {
    left: 0,
    top: 0,
  },
  groupInner: {
    backgroundColor: Color.mistyrose,
  },
  inHomeDaycare: {
    top: 94,
    left: 19,
  },
  inHomeDaycare1Icon: {
    left: 37,
    width: 70,
    height: 59,
    top: 22,
    position: "absolute",
  },
  rectangleContainer: {
    left: 154,
  },
  rectangleView: {
    backgroundColor: Color.darkseagreen,
  },
  homeBasedCreches: {
    left: 33,
  },
  teacherhome010111Icon: {
    left: 43,
    width: 59,
    height: 63,
  },
  groupView: {
    left: 0,
  },
  sharedNanny: {
    left: 29,
  },
  sharedNanny1Icon: {
    width: 47,
    height: 59,
    top: 22,
  },
  rectangleParent1: {
    left: 154,
  },
  nanny: {
    left: 52,
  },
  nanny1Icon: {
    top: 20,
    left: 40,
    width: 64,
    height: 59,
    position: "absolute",
  },
  rectangleParent2: {
    left: 0,
  },
  babysitter: {
    left: 41,
  },
  babysitter1Icon: {
    left: 57,
    width: 31,
    height: 59,
    top: 22,
    position: "absolute",
  },
  rectangleParent3: {
    left: 154,
  },
  auPair: {
    left: 50,
  },
  auPair1Icon: {
    left: 29,
    height: 59,
    top: 22,
  },
  rectangleParent4: {
    left: 0,
  },
  relativeCare: {
    left: 31,
  },
  icon: {
    top: 10,
    left: 137,
    width: 129,
    height: 86,
    position: "absolute",
  },
  rectangleParent5: {
    left: 154,
  },
  traditionalDaycareCenter: {
    left: 13,
  },
  daycare11: {
    top: 12,
  },
  baby526658644038601Icon: {
    top: 14,
    left: 39,
    width: 67,
    height: 67,
    position: "absolute",
  },
  rectangleParent6: {
    left: 0,
  },
  workplaceCreches: {
    left: 12,
  },
  workplaceCreches1Icon: {
    top: 23,
    left: 116,
    height: 56,
  },
  rectangleParent7: {
    left: 154,
  },
  preschool: {
    left: 42,
  },
  zeroNumber486364540562911Icon: {
    top: 17,
    left: 38,
    width: 68,
    height: 68,
    position: "absolute",
  },
  rectangleParent8: {
    left: 0,
  },
  daycareCentresAttached: {
    top: 62,
    left: 9,
  },
  daycareCentresAttachedToInIcon: {
    top: 11,
    width: 48,
    height: 49,
  },
  rectangleParent9: {
    top: 780,
    left: 0,
  },
  groupParent: {
    top: 2,
    height: 900,
    left: 0,
  },
  crechesInner: {
    top: 257,
    left: 30,
    height: 510,
  },
  adminChild: {
    borderTopLeftRadius: Border.br_23xl,
    borderTopRightRadius: Border.br_23xl,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    backgroundColor: Color.white,
  },
  creches1: {
    left: 54,
    fontSize: FontSize.size_lg,
    fontWeight: "800",
    fontFamily: FontFamily.latoExtrabold,
    width: 111,
    height: 20,
    color: Color.lightLabelPrimary,
    top: 49,
    textAlign: "left",
  },
  icon1: {
    height: "100%",
    width: "100%",
  },
  arrowLeft1: {
    left: 24,
    width: 24,
    height: 23,
  },
  creches: {
    borderRadius: Border.br_21xl,
    flex: 1,
    height: 792,
    width: "100%",
    backgroundColor: Color.white,
  },
});

export default CrechesList;
