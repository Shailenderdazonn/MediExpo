import * as React from "react";
import { StyleSheet, View, Text, Image } from "react-native";
import { Color, FontFamily, FontSize, Border } from "../GlobalStyles";

const PatientSignup1 = () => {
  return (
    <View style={styles.patientSignup}>
      <View
        style={[
          styles.frame44a,
          styles.frame44aPosition,
          styles.frame44aPosition1,
        ]}
      >
        <View style={styles.group8a4}>
          <View style={styles.rectangleParent}>
            <View style={[styles.groupChild, styles.groupChildLayout]} />
            <Text style={[styles.pinCode, styles.cityTypo, styles.cityTypo1]}>
              Pin Code
            </Text>
          </View>
          <View style={styles.rectangleGroup}>
            <View style={[styles.groupItem, styles.groupChildLayout]} />
            <Text style={[styles.pinCode, styles.cityTypo, styles.cityTypo1]}>
              State
            </Text>
          </View>
          <View
            style={[
              styles.vectorParent,
              styles.vectorPosition,
              styles.vectorPosition1,
            ]}
          >
            <Image
              style={[styles.vectorIcon, styles.vectorIconPosition2]}
              resizeMode="cover"
              source={require("../assets/vector1.png")}
            />
            <View style={[styles.groupInner, styles.groupChildLayout]} />
            <Text style={[styles.city, styles.cityTypo, styles.cityTypo1]}>
              City
            </Text>
          </View>
          <View style={[styles.vectorGroup, styles.vectorPosition]}>
            <Image
              style={[styles.vectorIcon1, styles.vectorIconPosition1]}
              resizeMode="cover"
              source={require("../assets/vector2.png")}
            />
            <View style={[styles.rectangleView, styles.groupChildLayout]} />
            <Text style={[styles.address, styles.cityTypo, styles.cityTypo1]}>
              Address
            </Text>
          </View>
          <View style={[styles.rectangleContainer, styles.parentLayout]}>
            <View style={[styles.groupChild1, styles.groupChildLayout]} />
            <Text style={[styles.pinCode, styles.cityTypo, styles.cityTypo1]}>
              Age
            </Text>
          </View>
          <View style={[styles.groupView, styles.parentLayout]}>
            <View style={[styles.groupChild1, styles.groupChildLayout]} />
            <Image
              style={[styles.ellipseIcon, styles.ellipseIconLayout]}
              resizeMode="cover"
              source={require("../assets/ellipse-7.png")}
            />
            <Text style={[styles.male, styles.cityTypo, styles.cityTypo1]}>
              Male
            </Text>
            <Image
              style={[styles.groupChild3, styles.ellipseIconLayout]}
              resizeMode="cover"
              source={require("../assets/ellipse-7.png")}
            />
            <Text style={[styles.female, styles.cityTypo, styles.cityTypo1]}>
              Female
            </Text>
            <Text style={[styles.gender, styles.cityTypo, styles.cityTypo1]}>
              Gender
            </Text>
          </View>
          <View style={[styles.mobileNumberParent, styles.parentLayout]}>
            <Text
              style={[styles.mobileNumber, styles.cityTypo, styles.cityTypo1]}
            >
              Mobile Number
            </Text>
            <View style={[styles.groupChild1, styles.groupChildLayout]} />
          </View>
          <View style={[styles.fullNameParent, styles.parentLayout]}>
            <Text
              style={[styles.mobileNumber, styles.cityTypo, styles.cityTypo1]}
            >
              Full Name
            </Text>
            <View style={[styles.groupChild1, styles.groupChildLayout]} />
          </View>
          <View style={[styles.rectangleParent1, styles.frame44aPosition1]}>
            <View style={[styles.groupChild6, styles.groupChildLayout]} />
            <Text
              style={[
                styles.servicesRequired,
                styles.cityTypo,
                styles.cityTypo1,
              ]}
            >
              Services Required
            </Text>
            <Image
              style={[styles.vectorIcon2, styles.vectorIconPosition]}
              resizeMode="cover"
              source={require("../assets/vector3.png")}
            />
          </View>
          <View style={[styles.rectangleParent2, styles.groupChild7Layout]}>
            <View style={[styles.groupChild7, styles.groupChild7Layout]} />
            <Text style={[styles.create, styles.createTypo]}>Create</Text>
          </View>
        </View>
      </View>
      <View style={[styles.loginText, styles.loginTextFlexBox]}>
        <Text style={[styles.signUp, styles.createTypo]}>{`Sign Up `}</Text>
      </View>
      <View style={styles.logo}>
        <Image
          style={styles.image2Icon}
          resizeMode="cover"
          source={require("../assets/image-22.png")}
        />
      </View>
      <View style={styles.uploadImage}>
        <View style={[styles.uploadImageInner, styles.loginTextFlexBox]}>
          <Image
            style={styles.frameChild}
            resizeMode="cover"
            source={require("../assets/group-28.png")}
          />
        </View>
        <View style={[styles.addPhoto2, styles.frame44aPosition]}>
          <Image
            style={styles.vectorIcon3}
            resizeMode="cover"
            source={require("../assets/vector4.png")}
          />
        </View>
        <View style={[styles.addProfilePhotoWrapper, styles.loginTextFlexBox]}>
          <Text style={[styles.addProfilePhoto, styles.cityTypo]}>
            Add Profile Photo
          </Text>
        </View>
      </View>
      <View style={styles.patientSignupInner}>
        <View style={styles.groupWrapper}>
          <View style={styles.group8a4}>
            <View style={styles.rectangleParent}>
              <View style={[styles.groupChild, styles.groupChildLayout]} />
              <Text style={[styles.pinCode, styles.cityTypo, styles.cityTypo1]}>
                Pin Code
              </Text>
            </View>
            <View style={styles.rectangleGroup}>
              <View style={[styles.groupItem, styles.groupChildLayout]} />
              <Text style={[styles.pinCode, styles.cityTypo, styles.cityTypo1]}>
                State
              </Text>
            </View>
            <View
              style={[
                styles.vectorContainer,
                styles.vectorPosition,
                styles.vectorPosition1,
              ]}
            >
              <Image
                style={[styles.vectorIcon4, styles.vectorIconPosition2]}
                resizeMode="cover"
                source={require("../assets/vector5.png")}
              />
              <View style={[styles.groupChild10, styles.groupChildLayout]} />
              <Text style={[styles.city1, styles.cityTypo, styles.cityTypo1]}>
                City
              </Text>
            </View>
            <View style={styles.rectangleParent5}>
              <View style={[styles.groupChild11, styles.groupChildLayout]} />
              <Text
                style={[styles.address1, styles.cityTypo, styles.cityTypo1]}
              >
                Address
              </Text>
              <Image
                style={[styles.vectorIcon5, styles.vectorIconPosition1]}
                resizeMode="cover"
                source={require("../assets/vector6.png")}
              />
            </View>
            <View style={[styles.rectangleContainer, styles.parentLayout]}>
              <View style={[styles.groupChild1, styles.groupChildLayout]} />
              <Text style={[styles.pinCode, styles.cityTypo, styles.cityTypo1]}>
                Age
              </Text>
            </View>
            <View style={[styles.groupView, styles.parentLayout]}>
              <View style={[styles.groupChild1, styles.groupChildLayout]} />
              <Image
                style={[styles.ellipseIcon, styles.ellipseIconLayout]}
                resizeMode="cover"
                source={require("../assets/ellipse-7.png")}
              />
              <Text style={[styles.male, styles.cityTypo, styles.cityTypo1]}>
                Male
              </Text>
              <Image
                style={[styles.groupChild3, styles.ellipseIconLayout]}
                resizeMode="cover"
                source={require("../assets/ellipse-7.png")}
              />
              <Text style={[styles.female, styles.cityTypo, styles.cityTypo1]}>
                Female
              </Text>
              <Text style={[styles.gender, styles.cityTypo, styles.cityTypo1]}>
                Gender
              </Text>
            </View>
            <View style={[styles.mobileNumberParent, styles.parentLayout]}>
              <Text
                style={[styles.mobileNumber, styles.cityTypo, styles.cityTypo1]}
              >
                Mobile Number
              </Text>
              <View style={[styles.groupChild1, styles.groupChildLayout]} />
            </View>
            <View style={[styles.fullNameParent, styles.parentLayout]}>
              <Text
                style={[styles.mobileNumber, styles.cityTypo, styles.cityTypo1]}
              >
                Full Name
              </Text>
              <View style={[styles.groupChild1, styles.groupChildLayout]} />
            </View>
            <View style={styles.rectangleParent8}>
              <View style={[styles.groupChild18, styles.groupChildLayout]} />
              <Text
                style={[
                  styles.servicesRequired1,
                  styles.cityTypo,
                  styles.cityTypo1,
                ]}
              >
                Services Required
              </Text>
              <Image
                style={[styles.vectorIcon6, styles.vectorIconPosition]}
                resizeMode="cover"
                source={require("../assets/vector7.png")}
              />
            </View>
            <View style={[styles.rectangleParent2, styles.groupChild7Layout]}>
              <View style={[styles.groupChild7, styles.groupChild7Layout]} />
              <Text style={[styles.create, styles.createTypo]}>Create</Text>
            </View>
          </View>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  frame44aPosition: {
    overflow: "hidden",
    position: "absolute",
  },
  frame44aPosition1: {
    top: 344,
    width: 274,
  },
  groupChildLayout: {
    height: 2,
    backgroundColor: Color.gray_100,
    left: 0,
    width: 274,
    position: "absolute",
  },
  cityTypo: {
    textAlign: "left",
    color: Color.gray_100,
    fontFamily: FontFamily.lato,
  },
  cityTypo1: {
    fontSize: FontSize.size_sm,
    color: Color.gray_100,
    fontFamily: FontFamily.lato,
    position: "absolute",
  },
  vectorPosition: {
    left: "0%",
    right: "0%",
    position: "absolute",
    width: "100%",
  },
  vectorPosition1: {
    bottom: "43.83%",
    left: "0%",
    right: "0%",
  },
  vectorIconPosition2: {
    maxHeight: "100%",
    left: "90.15%",
    right: "6.1%",
    top: "0%",
    width: "3.75%",
    maxWidth: "100%",
    overflow: "hidden",
    position: "absolute",
  },
  vectorIconPosition1: {
    left: "89.78%",
    right: "6.57%",
    width: "3.65%",
    maxHeight: "100%",
    maxWidth: "100%",
    top: "0%",
    overflow: "hidden",
    position: "absolute",
  },
  parentLayout: {
    height: 26,
    left: 0,
    width: 274,
    position: "absolute",
  },
  ellipseIconLayout: {
    height: 12,
    width: 12,
    top: 2,
    position: "absolute",
  },
  vectorIconPosition: {
    right: "6.2%",
    width: "3.65%",
    maxHeight: "100%",
    maxWidth: "100%",
    left: "90.15%",
    top: "0%",
    overflow: "hidden",
    position: "absolute",
  },
  groupChild7Layout: {
    height: 37,
    left: 0,
    width: 274,
    position: "absolute",
  },
  createTypo: {
    fontFamily: FontFamily.poppins,
    fontWeight: "700",
    fontSize: FontSize.size_xl,
    textAlign: "left",
  },
  loginTextFlexBox: {
    flexDirection: "row",
    position: "absolute",
  },
  groupChild: {
    top: 22,
  },
  pinCode: {
    left: 0,
    top: 0,
  },
  rectangleParent: {
    top: 404,
    height: 24,
    left: 0,
    width: 274,
    position: "absolute",
  },
  groupItem: {
    top: 21,
  },
  rectangleGroup: {
    top: 352,
    height: 23,
    left: 0,
    width: 274,
    position: "absolute",
  },
  vectorIcon: {
    height: "5.69%",
    bottom: "94.31%",
  },
  groupInner: {
    top: 91,
  },
  city: {
    top: 67,
    left: 0,
  },
  vectorParent: {
    height: "16.22%",
    top: "39.96%",
  },
  vectorIcon1: {
    height: "5.99%",
    bottom: "94.01%",
  },
  rectangleView: {
    top: 76,
  },
  address: {
    top: 52,
    left: 0,
  },
  vectorGroup: {
    height: "13.57%",
    top: "31.12%",
    bottom: "55.3%",
    left: "0%",
    right: "0%",
  },
  groupChild1: {
    top: 24,
  },
  rectangleContainer: {
    top: 166,
  },
  ellipseIcon: {
    left: 126,
  },
  male: {
    left: 145,
    top: 0,
  },
  groupChild3: {
    left: 208,
  },
  female: {
    left: 224,
    top: 0,
  },
  gender: {
    top: 1,
    width: 47,
    left: 0,
  },
  groupView: {
    top: 110,
  },
  mobileNumber: {
    left: 0,
    top: 0,
    width: 274,
  },
  mobileNumberParent: {
    top: 55,
  },
  fullNameParent: {
    top: 0,
  },
  groupChild6: {
    top: 128,
  },
  servicesRequired: {
    top: 104,
    left: 0,
  },
  vectorIcon2: {
    height: "4.09%",
    bottom: "95.91%",
  },
  rectangleParent1: {
    height: 130,
    left: 0,
    width: 274,
    position: "absolute",
  },
  groupChild7: {
    borderRadius: Border.br_8xs,
    backgroundColor: Color.tomato_100,
    top: 0,
  },
  create: {
    top: 7,
    left: 99,
    color: Color.white,
    position: "absolute",
  },
  rectangleParent2: {
    top: 538,
  },
  group8a4: {
    height: 575,
    left: 0,
    top: 0,
    width: 274,
    position: "absolute",
  },
  frame44a: {
    left: 42,
    height: 436,
    display: "none",
    width: 274,
  },
  signUp: {
    color: Color.darkslateblue,
    flex: 1,
    fontFamily: FontFamily.poppins,
    fontWeight: "700",
    fontSize: FontSize.size_xl,
  },
  loginText: {
    top: 148,
    left: 146,
    width: 76,
  },
  image2Icon: {
    alignSelf: "stretch",
    height: 52,
    maxWidth: "100%",
    overflow: "hidden",
    width: "100%",
  },
  logo: {
    top: 64,
    left: 129,
    width: 109,
    position: "absolute",
  },
  frameChild: {
    width: 85,
    height: 85,
  },
  uploadImageInner: {
    left: 0,
    top: 0,
  },
  vectorIcon3: {
    width: 25,
    height: 22,
  },
  addPhoto2: {
    top: 25,
    left: 27,
    paddingHorizontal: 1,
    paddingVertical: 3,
  },
  addProfilePhoto: {
    fontSize: FontSize.size_3xs,
  },
  addProfilePhotoWrapper: {
    top: 88,
    left: 2,
  },
  uploadImage: {
    top: 203,
    left: 150,
    width: 80,
    height: 99,
    position: "absolute",
  },
  vectorIcon4: {
    height: "5.41%",
    bottom: "94.59%",
  },
  groupChild10: {
    top: 83,
  },
  city1: {
    top: 59,
    left: 0,
  },
  vectorContainer: {
    height: "14.7%",
    top: "41.48%",
  },
  groupChild11: {
    top: 81,
  },
  address1: {
    top: 57,
    left: 0,
  },
  vectorIcon5: {
    height: "4.84%",
    bottom: "95.16%",
  },
  rectangleParent5: {
    top: 174,
    height: 83,
    left: 0,
    width: 274,
    position: "absolute",
  },
  groupChild18: {
    top: 165,
  },
  servicesRequired1: {
    top: 141,
    left: 0,
  },
  vectorIcon6: {
    height: "2.74%",
    bottom: "97.26%",
  },
  rectangleParent8: {
    top: 307,
    height: 167,
    left: 0,
    width: 274,
    position: "absolute",
  },
  groupWrapper: {
    top: 2,
    height: 575,
    left: 0,
    width: 274,
    position: "absolute",
  },
  patientSignupInner: {
    top: 331,
    left: 35,
    width: 298,
    height: 439,
    position: "absolute",
  },
  patientSignup: {
    borderRadius: Border.br_21xl,
    backgroundColor: Color.whitesmoke_300,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    height: 792,
    width: "100%",
    flex: 1,
  },
});

export default PatientSignup1;
