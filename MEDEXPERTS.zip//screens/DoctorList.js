import * as React from "react";
import { StyleSheet, View, Text, Image, Pressable } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { Color, Border, FontFamily, FontSize } from "../GlobalStyles";

const DoctorList = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.doctor}>
      <View style={[styles.searchMedical, styles.searchLayout]}>
        <View
          style={[
            styles.searchMedicalChild,
            styles.groupParentPosition,
            styles.searchLayout,
          ]}
        />
        <Text style={styles.searchDoctor}>Search Doctor</Text>
        <Image
          style={[styles.searchIcon, styles.searchIconPosition]}
          resizeMode="cover"
          source={require("../assets/search.png")}
        />
      </View>
      <View style={styles.adminWrapper}>
        <View style={styles.adminPosition}>
          <View style={[styles.adminChild, styles.adminPosition]} />
          <View
            style={[styles.arrowLeft1Parent, styles.plasticSurgeonsPosition]}
          >
            <Pressable
              style={styles.arrowLeft1}
              onPress={() => navigation.navigate("CategoriesList")}
            >
              <Image
                style={styles.icon}
                resizeMode="cover"
                source={require("../assets/arrowleft-1.png")}
              />
            </Pressable>
            <Text style={[styles.doctor1, styles.ml6]}>Doctor</Text>
          </View>
        </View>
      </View>
      <View style={[styles.doctorInner, styles.doctorInnerLayout]}>
        <View
          style={[
            styles.groupParent,
            styles.doctorInnerLayout,
            styles.groupParentPosition,
          ]}
        >
          <View style={[styles.rectangleParent, styles.groupChildLayout1]}>
            <View
              style={[
                styles.groupChild,
                styles.groupChildBg,
                styles.groupChildLayout1,
              ]}
            />
            <Text
              style={[
                styles.anesthesiologists,
                styles.pulmonologistsTypo,
                styles.generalSurgeonsPosition,
              ]}
            >
              Anesthesiologists
            </Text>
            <Image
              style={[styles.anesthesiologists1Icon, styles.iconPosition3]}
              resizeMode="cover"
              source={require("../assets/anesthesiologists-1.png")}
            />
          </View>
          <Pressable
            style={styles.groupChildPosition}
            onPress={() => navigation.navigate("AllergistsImmunologistsList")}
          >
            <View
              style={[
                styles.groupItem,
                styles.groupChildPosition,
                styles.groupChildLayout,
              ]}
            />
            <Image
              style={[styles.allergists1Icon, styles.iconLayout8]}
              resizeMode="cover"
              source={require("../assets/allergists-1.png")}
            />
            <Text
              style={[
                styles.allergistsImmunologists,
                styles.pulmonologistsTypo,
              ]}
            >{`Allergists/
Immunologists`}</Text>
          </Pressable>
          <View style={[styles.rectangleContainer, styles.groupViewPosition]}>
            <View
              style={[
                styles.groupItem,
                styles.groupChildPosition,
                styles.groupChildLayout,
              ]}
            />
            <Text
              style={[styles.colonAndRectal, styles.andTypo]}
            >{`Colon and Rectal
Surgeons`}</Text>
            <Image
              style={[styles.colon21Icon, styles.iconLayout7]}
              resizeMode="cover"
              source={require("../assets/colon2-1.png")}
            />
          </View>
          <View style={[styles.groupView, styles.groupViewPosition]}>
            <View
              style={[
                styles.rectangleView,
                styles.groupChildPosition,
                styles.groupChildLayout,
              ]}
            />
            <Text style={[styles.cardiologists, styles.cardiologistsPosition]}>
              Cardiologists
            </Text>
            <Image
              style={[styles.cardiologists3Icon, styles.hematologistsPosition]}
              resizeMode="cover"
              source={require("../assets/cardiologists-3.png")}
            />
          </View>
          <View
            style={[styles.rectangleParent1, styles.rectangleParentPosition15]}
          >
            <View style={[styles.groupChildPosition, styles.groupChildBg]} />
            <Text
              style={[
                styles.dermatologists,
                styles.dermatologistsPosition,
                styles.surgeonsTypo,
              ]}
            >
              Dermatologists
            </Text>
            <Image
              style={styles.dermatologists1Icon}
              resizeMode="cover"
              source={require("../assets/dermatologists-1.png")}
            />
          </View>
          <View
            style={[styles.rectangleParent2, styles.rectangleParentPosition15]}
          >
            <View
              style={[
                styles.groupChild2,
                styles.groupChildPosition,
                styles.groupChildLayout,
              ]}
            />
            <Text
              style={[styles.criticalCareMedicine, styles.andTypo]}
            >{`Critical Care
Medicine Specialists`}</Text>
            <Image
              style={[styles.criticalCare1Icon, styles.iconPosition3]}
              resizeMode="cover"
              source={require("../assets/critical-care-1.png")}
            />
          </View>
          <View
            style={[styles.rectangleParent3, styles.rectangleParentPosition14]}
          >
            <View
              style={[
                styles.groupItem,
                styles.groupChildPosition,
                styles.groupChildLayout,
              ]}
            />
            <Text
              style={[
                styles.gastroenterologists,
                styles.medicalGeneticistsPosition,
              ]}
            >
              Gastroenterologists
            </Text>
            <Image
              style={[styles.gastroenterologists1Icon, styles.iconPosition2]}
              resizeMode="cover"
              source={require("../assets/gastroenterologists-1.png")}
            />
          </View>
          <View
            style={[styles.rectangleParent4, styles.rectangleParentPosition14]}
          >
            <View
              style={[
                styles.rectangleView,
                styles.groupChildPosition,
                styles.groupChildLayout,
              ]}
            />
            <Text style={[styles.endocrinologists, styles.surgeonsTypo]}>
              Endocrinologists
            </Text>
            <Image
              style={[styles.icon1, styles.iconLayout6]}
              resizeMode="cover"
              source={require("../assets/4799049-1.png")}
            />
          </View>
          <View
            style={[styles.rectangleParent5, styles.rectangleParentPosition13]}
          >
            <View style={styles.groupChildBg} />
            <Text
              style={[
                styles.hematologists,
                styles.hematologistsPosition,
                styles.surgeonsTypo,
              ]}
            >
              Hematologists
            </Text>
            <Image
              style={[styles.hematologists1Icon, styles.iconLayout6]}
              resizeMode="cover"
              source={require("../assets/hematologists-1.png")}
            />
          </View>
          <View
            style={[styles.rectangleParent6, styles.rectangleParentPosition13]}
          >
            <View
              style={[
                styles.groupChild2,
                styles.groupChildPosition,
                styles.groupChildLayout,
              ]}
            />
            <Text
              style={[styles.geriatricMedicineSpecialists, styles.andTypo]}
            >{`Geriatric Medicine
Specialists`}</Text>
            <Image
              style={styles.geriatricMedicineSpecialistsIcon}
              resizeMode="cover"
              source={require("../assets/geriatricmedicinespecialists-1.png")}
            />
          </View>
          <View
            style={[styles.rectangleParent7, styles.rectangleParentPosition12]}
          >
            <View
              style={[
                styles.groupChild7,
                styles.groupChildPosition,
                styles.groupChildLayout,
              ]}
            />
            <Text
              style={[
                styles.infectiousDiseaseSpecialists,
                styles.hospicePalliativeTypo,
              ]}
            >{`Infectious Disease
Specialists`}</Text>
            <Image
              style={[
                styles.infectiousDiseaseSpecialistsIcon,
                styles.iconLayout4,
                styles.iconLayout5,
              ]}
              resizeMode="cover"
              source={require("../assets/infectiousdiseasespecialists-1.png")}
            />
          </View>
          <View
            style={[styles.rectangleParent8, styles.rectangleParentPosition12]}
          >
            <View
              style={[
                styles.groupChild8,
                styles.groupChildPosition,
                styles.groupChildLayout,
              ]}
            />
            <Text
              style={[styles.hospicePalliative, styles.hospicePalliativeTypo]}
            >{`Hospice & Palliative
Medicine Specialists`}</Text>
            <Image
              style={[styles.hospicePalliativeMedicineIcon, styles.iconLayout7]}
              resizeMode="cover"
              source={require("../assets/hospicepalliativemedicinespecialists-1.png")}
            />
          </View>
          <View
            style={[styles.rectangleParent9, styles.rectangleParentPosition11]}
          >
            <View style={styles.groupChildBg} />
            <Text
              style={[
                styles.medicalGeneticists,
                styles.medicalGeneticistsPosition,
              ]}
            >
              Medical Geneticists
            </Text>
            <Image
              style={[
                styles.scientificSpiralGeneticDnaIcon,
                styles.iconPosition1,
              ]}
              resizeMode="cover"
              source={require("../assets/scientificspiralgeneticdna3diconillustrationpng-1.png")}
            />
          </View>
          <View
            style={[styles.rectangleParent10, styles.rectangleParentPosition11]}
          >
            <View
              style={[
                styles.groupChild2,
                styles.groupChildPosition,
                styles.groupChildLayout,
              ]}
            />
            <Text
              style={[
                styles.internists,
                styles.icon2Position,
                styles.surgeonsTypo,
              ]}
            >
              Internists
            </Text>
            <Image
              style={[styles.removebgPreview1Icon, styles.iconLayout3]}
              resizeMode="cover"
              source={require("../assets/5503237removebgpreview-1.png")}
            />
          </View>
          <View
            style={[styles.rectangleParent11, styles.rectangleParentPosition10]}
          >
            <View
              style={[
                styles.groupChild7,
                styles.groupChildPosition,
                styles.groupChildLayout,
              ]}
            />
            <Text style={[styles.neurologists, styles.surgeonsTypo]}>
              Neurologists
            </Text>
            <Image
              style={[
                styles.humanBrainSymbolIconPng1,
                styles.iconLayout2,
                styles.iconLayout4,
              ]}
              resizeMode="cover"
              source={require("../assets/humanbrainsymboliconpng-1.png")}
            />
          </View>
          <View
            style={[styles.rectangleParent12, styles.rectangleParentPosition10]}
          >
            <View
              style={[
                styles.groupChild8,
                styles.groupChildPosition,
                styles.groupChildLayout,
              ]}
            />
            <Text style={[styles.nephrologists, styles.surgeonsTypo]}>
              Nephrologists
            </Text>
            <Image
              style={[styles.iconPosition, styles.iconLayout2]}
              resizeMode="cover"
              source={require("../assets/nephrologists-1.png")}
            />
          </View>
          <View
            style={[styles.rectangleParent13, styles.rectangleParentPosition9]}
          >
            <View style={styles.groupChildBg} />
            <Text
              style={[
                styles.oncologists,
                styles.osteopathsPosition,
                styles.surgeonsTypo,
              ]}
            >
              Oncologists
            </Text>
            <Image
              style={[styles.icon2, styles.icon2Position]}
              resizeMode="cover"
              source={require("../assets/5503251-1.png")}
            />
          </View>
          <View
            style={[styles.rectangleParent14, styles.rectangleParentPosition9]}
          >
            <View
              style={[
                styles.groupChild2,
                styles.groupChildPosition,
                styles.groupChildLayout,
              ]}
            />
            <Text
              style={[styles.andTypo, styles.generalSurgeonsPosition]}
            >{`Obstetricians and
Gynecologists`}</Text>
            <Image
              style={styles.icon3}
              resizeMode="cover"
              source={require("../assets/6558415-1.png")}
            />
          </View>
          <View
            style={[styles.rectangleParent15, styles.rectangleParentPosition8]}
          >
            <View
              style={[
                styles.groupChild7,
                styles.groupChildPosition,
                styles.groupChildLayout,
              ]}
            />
            <Text
              style={[
                styles.osteopaths,
                styles.osteopathsPosition,
                styles.surgeonsTypo,
              ]}
            >
              Osteopaths
            </Text>
            <Image
              style={[styles.osteopaths1Icon, styles.iconPosition1]}
              resizeMode="cover"
              source={require("../assets/osteopaths-1.png")}
            />
          </View>
          <View
            style={[styles.rectangleParent16, styles.rectangleParentPosition8]}
          >
            <View
              style={[
                styles.groupChild8,
                styles.groupChildPosition,
                styles.groupChildLayout,
              ]}
            />
            <Text
              style={[
                styles.ophthalmologists,
                styles.surgeonsTypo,
                styles.generalSurgeonsPosition,
              ]}
            >
              Ophthalmologists
            </Text>
            <Image
              style={[styles.icon4, styles.iconLayout1]}
              resizeMode="cover"
              source={require("../assets/6430622-1.png")}
            />
          </View>
          <View
            style={[styles.rectangleParent17, styles.rectangleParentPosition7]}
          >
            <View style={styles.groupChildBg} />
            <Text
              style={[
                styles.pathologists,
                styles.pathologistsPosition,
                styles.surgeonsTypo,
              ]}
            >
              Pathologists
            </Text>
            <Image
              style={[styles.pngtreeMicroscope3dIconEdu, styles.iconLayout1]}
              resizeMode="cover"
              source={require("../assets/pngtreemicroscope3diconeducationandscientistconceptimagespngimage-6595586-1.png")}
            />
          </View>
          <View
            style={[styles.rectangleParent18, styles.rectangleParentPosition7]}
          >
            <View
              style={[
                styles.groupChild2,
                styles.groupChildPosition,
                styles.groupChildLayout,
              ]}
            />
            <Text style={[styles.otolaryngologists, styles.surgeonsTypo]}>
              Otolaryngologists
            </Text>
            <Image
              style={[styles.otolaryngologists1Icon, styles.iconPosition2]}
              resizeMode="cover"
              source={require("../assets/otolaryngologists-1.png")}
            />
          </View>
          <View
            style={[styles.rectangleParent19, styles.rectangleParentPosition6]}
          >
            <View
              style={[
                styles.groupChild7,
                styles.groupChildPosition,
                styles.groupChildLayout,
              ]}
            />
            <Text
              style={[
                styles.osteopaths,
                styles.osteopathsPosition,
                styles.surgeonsTypo,
              ]}
            >
              Physiatrists
            </Text>
            <Image
              style={styles.doctor556558447151291Icon}
              resizeMode="cover"
              source={require("../assets/doctor55655844715129-1.png")}
            />
          </View>
          <View
            style={[styles.rectangleParent20, styles.rectangleParentPosition6]}
          >
            <View
              style={[
                styles.groupChild8,
                styles.groupChildPosition,
                styles.groupChildLayout,
              ]}
            />
            <Text style={[styles.pediatricians, styles.cardiologistsPosition]}>
              Pediatricians
            </Text>
            <Image
              style={[styles.pngtreeKidOnMedicalCheckUIcon, styles.iconLayout2]}
              resizeMode="cover"
              source={require("../assets/pngtreekidonmedicalcheckupwithmalepediatricianpngimage-5081085removebgpreview-1-1.png")}
            />
          </View>
          <View
            style={[styles.rectangleParent21, styles.rectangleParentPosition5]}
          >
            <View style={styles.groupChildBg} />
            <Text style={[styles.podiatrists, styles.surgeonsTypo]}>
              Podiatrists
            </Text>
            <Image
              style={[
                styles.kisspngFootAndAnkleSurgeryIcon,
                styles.pathologistsPosition,
              ]}
              resizeMode="cover"
              source={require("../assets/kisspngfootandanklesurgerypodiatristpodiatrydiabetibluefootprints5a7a3e9c978c94-1.png")}
            />
          </View>
          <View
            style={[styles.rectangleParent22, styles.rectangleParentPosition5]}
          >
            <View
              style={[
                styles.groupChild2,
                styles.groupChildPosition,
                styles.groupChildLayout,
              ]}
            />
            <Text
              style={[
                styles.plasticSurgeons,
                styles.surgeonsTypo,
                styles.plasticSurgeonsPosition,
              ]}
            >
              Plastic Surgeons
            </Text>
            <Image
              style={styles.plasticSurgeons1}
              resizeMode="cover"
              source={require("../assets/plastic-surgeons-1.png")}
            />
          </View>
          <View
            style={[styles.rectangleParent23, styles.rectangleParentPosition4]}
          >
            <View
              style={[
                styles.groupChild7,
                styles.groupChildPosition,
                styles.groupChildLayout,
              ]}
            />
            <Text
              style={[
                styles.psychiatrists,
                styles.pathologistsPosition,
                styles.surgeonsTypo,
              ]}
            >
              Psychiatrists
            </Text>
            <Image
              style={[
                styles.mentalHealthAndMedicineIcoIcon,
                styles.dermatologistsPosition,
              ]}
              resizeMode="cover"
              source={require("../assets/mentalhealthandmedicineicon3dillustrationpng-1.png")}
            />
          </View>
          <View
            style={[styles.rectangleParent24, styles.rectangleParentPosition4]}
          >
            <View
              style={[
                styles.groupChild8,
                styles.groupChildPosition,
                styles.groupChildLayout,
              ]}
            />
            <Text
              style={[
                styles.preventiveMedicineSpecialistPosition,
                styles.andTypo,
              ]}
            >{`Preventive Medicine
Specialists`}</Text>
            <Image
              style={[styles.dRenderingMedicalReportWitIcon, styles.iconLayout]}
              resizeMode="cover"
              source={require("../assets/3drenderingmedicalreportwithbloodtubepillsandstethoscopesigninghealthchecklistmedicalcheckupreport3drenderillustrationpng-1.png")}
            />
          </View>
          <View
            style={[styles.rectangleParent25, styles.rectangleParentPosition3]}
          >
            <View style={styles.groupChildBg} />
            <Text style={[styles.radiologists, styles.surgeonsTypo]}>
              Radiologists
            </Text>
            <Image
              style={[styles.icon5, styles.iconLayout]}
              resizeMode="cover"
              source={require("../assets/4788914-1.png")}
            />
          </View>
          <View
            style={[styles.rectangleParent26, styles.rectangleParentPosition3]}
          >
            <View
              style={[
                styles.groupChild2,
                styles.groupChildPosition,
                styles.groupChildLayout,
              ]}
            />
            <Text
              style={[
                styles.pulmonologists,
                styles.dermatologistsPosition,
                styles.pulmonologistsTypo,
              ]}
            >
              Pulmonologists
            </Text>
            <Image
              style={[
                styles.lungs546347345516501Icon,
                styles.osteopathsPosition,
              ]}
              resizeMode="cover"
              source={require("../assets/lungs54634734551650-1.png")}
            />
          </View>
          <View
            style={[styles.rectangleParent27, styles.rectangleParentPosition2]}
          >
            <View
              style={[
                styles.groupChild7,
                styles.groupChildPosition,
                styles.groupChildLayout,
              ]}
            />
            <Text
              style={[styles.andTypo, styles.plasticSurgeonsPosition]}
            >{`Sleep Medicine
Specialists`}</Text>
            <Image
              style={[styles.sleepingPills3dRenderIcon, styles.iconLayout5]}
              resizeMode="cover"
              source={require("../assets/sleepingpills3drendericonillustrationpng-1.png")}
            />
          </View>
          <View
            style={[styles.rectangleParent28, styles.rectangleParentPosition2]}
          >
            <View
              style={[
                styles.groupChild8,
                styles.groupChildPosition,
                styles.groupChildLayout,
              ]}
            />
            <Text style={[styles.endocrinologists, styles.surgeonsTypo]}>
              Rheumatologists
            </Text>
            <Image
              style={[
                styles.pictoGenoux1RemovebgPrevieIcon,
                styles.preventiveMedicineSpecialistPosition,
              ]}
              resizeMode="cover"
              source={require("../assets/pictogenoux1removebgpreview-1.png")}
            />
          </View>
          <View
            style={[styles.rectangleParent29, styles.rectangleParentPosition1]}
          >
            <View style={styles.groupChildBg} />
            <Text
              style={[
                styles.generalSurgeons,
                styles.surgeonsTypo,
                styles.generalSurgeonsPosition,
              ]}
            >
              General Surgeons
            </Text>
            <Image
              style={[styles.imagesRemovebgPreview1Icon, styles.iconPosition]}
              resizeMode="cover"
              source={require("../assets/imagesremovebgpreview-1.png")}
            />
          </View>
          <View
            style={[styles.rectangleParent30, styles.rectangleParentPosition1]}
          >
            <View
              style={[
                styles.groupChild2,
                styles.groupChildPosition,
                styles.groupChildLayout,
              ]}
            />
            <Text
              style={[styles.andTypo, styles.searchIconPosition]}
            >{`Sports Medicine
Specialists`}</Text>
            <Image
              style={[
                styles.pngTransparentSportsMedicinIcon,
                styles.iconLayout8,
              ]}
              resizeMode="cover"
              source={require("../assets/pngtransparentsportsmedicinemedicineballexerciseballgraphyyogaballsburnfatburningsportorangethumbnailremovebgpreview-1.png")}
            />
          </View>
          <View
            style={[styles.rectangleParent31, styles.rectangleParentPosition]}
          >
            <View
              style={[
                styles.groupChild7,
                styles.groupChildPosition,
                styles.groupChildLayout,
              ]}
            />
            <Text
              style={[
                styles.osteopaths,
                styles.osteopathsPosition,
                styles.surgeonsTypo,
              ]}
            >
              Physiatrists
            </Text>
          </View>
          <View
            style={[styles.rectangleParent32, styles.rectangleParentPosition]}
          >
            <View
              style={[
                styles.groupChild8,
                styles.groupChildPosition,
                styles.groupChildLayout,
              ]}
            />
            <Text style={styles.urologists}>Urologists</Text>
            <Image
              style={[styles.urologistIcon1, styles.iconLayout3]}
              resizeMode="cover"
              source={require("../assets/urologisticon-1.png")}
            />
          </View>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  ml6: {
    marginLeft: 6,
  },
  searchLayout: {
    width: 304,
    height: 61,
    position: "absolute",
  },
  groupParentPosition: {
    top: 0,
    left: 0,
  },
  searchIconPosition: {
    left: 22,
    position: "absolute",
  },
  adminPosition: {
    height: 87,
    width: 357,
    left: 0,
    top: 0,
    position: "absolute",
  },
  plasticSurgeonsPosition: {
    left: 24,
    position: "absolute",
  },
  doctorInnerLayout: {
    width: 298,
    position: "absolute",
  },
  groupChildLayout1: {
    height: 116,
    width: 144,
    top: 0,
    position: "absolute",
  },
  groupChildBg: {
    backgroundColor: Color.forestgreen,
    borderRadius: Border.br_mini,
  },
  pulmonologistsTypo: {
    fontFamily: FontFamily.latoMedium,
    fontWeight: "500",
    fontSize: FontSize.size_sm,
    color: Color.lightLabelPrimary,
  },
  generalSurgeonsPosition: {
    left: 18,
    position: "absolute",
  },
  iconPosition3: {
    width: 48,
    left: 48,
    position: "absolute",
  },
  groupChildPosition: {
    height: 120,
    width: 144,
    left: 0,
    top: 0,
    position: "absolute",
  },
  groupChildLayout: {
    borderRadius: Border.br_mini,
    height: 120,
  },
  iconLayout8: {
    height: 57,
    width: 52,
    left: 46,
    position: "absolute",
  },
  groupViewPosition: {
    top: 130,
    height: 120,
    width: 144,
    position: "absolute",
  },
  andTypo: {
    top: 79,
    textAlign: "center",
    fontFamily: FontFamily.latoMedium,
    fontWeight: "500",
    fontSize: FontSize.size_sm,
    color: Color.lightLabelPrimary,
  },
  iconLayout7: {
    width: 47,
    position: "absolute",
  },
  cardiologistsPosition: {
    left: 32,
    top: 96,
    fontFamily: FontFamily.latoMedium,
    fontWeight: "500",
    fontSize: FontSize.size_sm,
    color: Color.lightLabelPrimary,
    position: "absolute",
  },
  hematologistsPosition: {
    left: 28,
    position: "absolute",
  },
  rectangleParentPosition15: {
    top: 260,
    height: 120,
    width: 144,
    position: "absolute",
  },
  dermatologistsPosition: {
    left: 25,
    position: "absolute",
  },
  surgeonsTypo: {
    top: 96,
    fontFamily: FontFamily.latoMedium,
    fontWeight: "500",
    fontSize: FontSize.size_sm,
    color: Color.lightLabelPrimary,
  },
  rectangleParentPosition14: {
    top: 390,
    height: 120,
    width: 144,
    position: "absolute",
  },
  medicalGeneticistsPosition: {
    left: 12,
    top: 96,
    fontFamily: FontFamily.latoMedium,
    fontWeight: "500",
    fontSize: FontSize.size_sm,
    color: Color.lightLabelPrimary,
    position: "absolute",
  },
  iconPosition2: {
    left: 51,
    top: 22,
    position: "absolute",
  },
  iconLayout6: {
    width: 51,
    height: 51,
    top: 22,
    position: "absolute",
  },
  rectangleParentPosition13: {
    top: 522,
    height: 120,
    width: 144,
    position: "absolute",
  },
  rectangleParentPosition12: {
    top: 652,
    height: 120,
    width: 144,
    position: "absolute",
  },
  hospicePalliativeTypo: {
    top: 78,
    textAlign: "center",
    fontFamily: FontFamily.latoMedium,
    fontWeight: "500",
    fontSize: FontSize.size_sm,
    color: Color.lightLabelPrimary,
    position: "absolute",
  },
  iconLayout4: {
    height: 52,
    position: "absolute",
  },
  iconLayout5: {
    width: 53,
    left: 46,
  },
  rectangleParentPosition11: {
    top: 782,
    height: 120,
    width: 144,
    position: "absolute",
  },
  iconPosition1: {
    left: 41,
    position: "absolute",
  },
  icon2Position: {
    left: 43,
    position: "absolute",
  },
  iconLayout3: {
    width: 57,
    left: 44,
    height: 57,
    position: "absolute",
  },
  rectangleParentPosition10: {
    top: 912,
    height: 120,
    width: 144,
    position: "absolute",
  },
  iconLayout2: {
    width: 61,
    left: 42,
  },
  rectangleParentPosition9: {
    top: 1042,
    height: 120,
    width: 144,
    position: "absolute",
  },
  osteopathsPosition: {
    left: 36,
    position: "absolute",
  },
  rectangleParentPosition8: {
    top: 1172,
    height: 120,
    width: 144,
    position: "absolute",
  },
  iconLayout1: {
    height: 64,
    width: 64,
    left: 40,
    position: "absolute",
  },
  rectangleParentPosition7: {
    top: 1302,
    height: 120,
    width: 144,
    position: "absolute",
  },
  pathologistsPosition: {
    left: 34,
    position: "absolute",
  },
  rectangleParentPosition6: {
    top: 1432,
    height: 120,
    width: 144,
    position: "absolute",
  },
  rectangleParentPosition5: {
    top: 1562,
    height: 120,
    width: 144,
    position: "absolute",
  },
  rectangleParentPosition4: {
    top: 1692,
    height: 120,
    width: 144,
    position: "absolute",
  },
  iconLayout: {
    height: 78,
    position: "absolute",
  },
  rectangleParentPosition3: {
    top: 1822,
    height: 120,
    width: 144,
    position: "absolute",
  },
  rectangleParentPosition2: {
    top: 1952,
    height: 120,
    width: 144,
    position: "absolute",
  },
  preventiveMedicineSpecialistPosition: {
    left: 9,
    position: "absolute",
  },
  rectangleParentPosition1: {
    top: 2082,
    height: 120,
    width: 144,
    position: "absolute",
  },
  iconPosition: {
    height: 54,
    top: 22,
    position: "absolute",
  },
  rectangleParentPosition: {
    top: 2212,
    height: 120,
    width: 144,
    position: "absolute",
  },
  searchMedicalChild: {
    borderRadius: Border.br_xs,
    backgroundColor: Color.whitesmoke_200,
    borderStyle: "solid",
    borderColor: "#0f6d65",
    borderWidth: 1,
    left: 0,
    height: 61,
  },
  searchDoctor: {
    left: 45,
    fontSize: FontSize.size_xs,
    fontFamily: FontFamily.latoRegular,
    color: Color.darkgray,
    width: 107,
    height: 17,
    textAlign: "left",
    top: 22,
    position: "absolute",
  },
  searchIcon: {
    width: 20,
    height: 22,
    top: 19,
  },
  searchMedical: {
    top: 146,
    height: 61,
    left: 27,
  },
  adminChild: {
    borderTopLeftRadius: Border.br_23xl,
    borderTopRightRadius: Border.br_23xl,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    backgroundColor: Color.white,
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  arrowLeft1: {
    width: 24,
    height: 23,
  },
  doctor1: {
    fontSize: FontSize.size_lg,
    fontWeight: "800",
    fontFamily: FontFamily.latoExtrabold,
    width: 111,
    height: 20,
    color: Color.lightLabelPrimary,
    textAlign: "left",
  },
  arrowLeft1Parent: {
    top: 49,
    flexDirection: "row",
  },
  adminWrapper: {
    height: 119,
    width: 357,
    left: 0,
    top: 0,
    position: "absolute",
  },
  groupChild: {
    left: 0,
  },
  anesthesiologists: {
    top: 92,
    width: 108,
    height: 16,
    textAlign: "left",
  },
  anesthesiologists1Icon: {
    top: 13,
    height: 55,
  },
  rectangleParent: {
    left: 154,
  },
  groupItem: {
    backgroundColor: Color.mistyrose,
  },
  allergists1Icon: {
    top: 9,
  },
  allergistsImmunologists: {
    top: 75,
    width: 90,
    height: 1,
    textAlign: "center",
    left: 27,
    position: "absolute",
  },
  colonAndRectal: {
    left: 20,
    position: "absolute",
  },
  colon21Icon: {
    height: 53,
    top: 17,
    left: 48,
    width: 47,
  },
  rectangleContainer: {
    left: 154,
  },
  rectangleView: {
    backgroundColor: Color.darkseagreen,
  },
  cardiologists: {
    textAlign: "left",
  },
  cardiologists3Icon: {
    width: 88,
    height: 53,
    top: 17,
  },
  groupView: {
    left: 0,
  },
  dermatologists: {
    textAlign: "center",
  },
  dermatologists1Icon: {
    left: 50,
    width: 44,
    height: 53,
    top: 17,
    position: "absolute",
  },
  rectangleParent1: {
    left: 154,
  },
  groupChild2: {
    backgroundColor: Color.darksalmon,
  },
  criticalCareMedicine: {
    left: 10,
    position: "absolute",
  },
  criticalCare1Icon: {
    height: 51,
    top: 17,
  },
  rectangleParent2: {
    left: 0,
  },
  gastroenterologists: {
    textAlign: "center",
  },
  gastroenterologists1Icon: {
    width: 42,
    height: 51,
  },
  rectangleParent3: {
    left: 154,
  },
  endocrinologists: {
    left: 21,
    textAlign: "center",
    position: "absolute",
  },
  icon1: {
    left: 47,
  },
  rectangleParent4: {
    left: 0,
  },
  hematologists: {
    textAlign: "left",
  },
  hematologists1Icon: {
    left: 46,
    width: 51,
  },
  rectangleParent5: {
    left: 154,
  },
  geriatricMedicineSpecialists: {
    left: 15,
    position: "absolute",
  },
  geriatricMedicineSpecialistsIcon: {
    left: 53,
    width: 38,
    height: 51,
    top: 22,
    position: "absolute",
  },
  rectangleParent6: {
    left: 0,
  },
  groupChild7: {
    backgroundColor: Color.mistyrose_100,
  },
  infectiousDiseaseSpecialists: {
    left: 16,
  },
  infectiousDiseaseSpecialistsIcon: {
    top: 18,
  },
  rectangleParent7: {
    left: 154,
  },
  groupChild8: {
    backgroundColor: Color.darkseagreen_100,
  },
  hospicePalliative: {
    left: 10,
  },
  hospicePalliativeMedicineIcon: {
    left: 96,
    height: 50,
    top: 20,
  },
  rectangleParent8: {
    left: 0,
  },
  medicalGeneticists: {
    textAlign: "left",
  },
  scientificSpiralGeneticDnaIcon: {
    width: 62,
    height: 62,
    top: 16,
  },
  rectangleParent9: {
    left: 154,
  },
  internists: {
    textAlign: "center",
  },
  removebgPreview1Icon: {
    top: 17,
  },
  rectangleParent10: {
    left: 0,
  },
  neurologists: {
    left: 33,
    textAlign: "center",
    position: "absolute",
  },
  humanBrainSymbolIconPng1: {
    top: 23,
  },
  rectangleParent11: {
    left: 154,
  },
  nephrologists: {
    left: 29,
    textAlign: "center",
    position: "absolute",
  },
  rectangleParent12: {
    left: 0,
  },
  oncologists: {
    textAlign: "left",
  },
  icon2: {
    width: 59,
    height: 59,
    top: 12,
  },
  rectangleParent13: {
    left: 154,
  },
  icon3: {
    left: 37,
    width: 71,
    height: 71,
    top: 11,
    position: "absolute",
  },
  rectangleParent14: {
    left: 0,
  },
  osteopaths: {
    textAlign: "center",
  },
  osteopaths1Icon: {
    width: 63,
    top: 20,
    height: 61,
  },
  rectangleParent15: {
    left: 154,
  },
  ophthalmologists: {
    textAlign: "center",
  },
  icon4: {
    top: 21,
  },
  rectangleParent16: {
    left: 0,
  },
  pathologists: {
    textAlign: "left",
  },
  pngtreeMicroscope3dIconEdu: {
    top: 18,
  },
  rectangleParent17: {
    left: 154,
  },
  otolaryngologists: {
    left: 17,
    textAlign: "center",
    position: "absolute",
  },
  otolaryngologists1Icon: {
    width: 43,
    height: 55,
  },
  rectangleParent18: {
    left: 0,
  },
  doctor556558447151291Icon: {
    left: 38,
    width: 68,
    height: 68,
    top: 12,
    position: "absolute",
  },
  rectangleParent19: {
    left: 154,
  },
  pediatricians: {
    textAlign: "center",
  },
  pngtreeKidOnMedicalCheckUIcon: {
    height: 69,
    top: 19,
    position: "absolute",
  },
  rectangleParent20: {
    left: 0,
  },
  podiatrists: {
    left: 39,
    textAlign: "left",
    position: "absolute",
  },
  kisspngFootAndAnkleSurgeryIcon: {
    width: 76,
    height: 65,
    top: 16,
  },
  rectangleParent21: {
    left: 154,
  },
  plasticSurgeons: {
    textAlign: "center",
  },
  plasticSurgeons1: {
    left: 102,
    width: 60,
    height: 60,
    top: 20,
    position: "absolute",
  },
  rectangleParent22: {
    left: 0,
  },
  psychiatrists: {
    textAlign: "center",
  },
  mentalHealthAndMedicineIcoIcon: {
    top: 1,
    width: 95,
    height: 95,
  },
  rectangleParent23: {
    left: 154,
  },
  dRenderingMedicalReportWitIcon: {
    width: 116,
    top: 11,
    left: 15,
  },
  rectangleParent24: {
    left: 0,
  },
  radiologists: {
    left: 35,
    textAlign: "left",
    position: "absolute",
  },
  icon5: {
    width: 78,
    top: 12,
    left: 33,
  },
  rectangleParent25: {
    left: 154,
  },
  pulmonologists: {
    top: 99,
    textAlign: "center",
  },
  lungs546347345516501Icon: {
    width: 73,
    height: 73,
    top: 17,
  },
  rectangleParent26: {
    left: 0,
  },
  sleepingPills3dRenderIcon: {
    top: 21,
    height: 53,
    position: "absolute",
  },
  rectangleParent27: {
    left: 154,
  },
  pictoGenoux1RemovebgPrevieIcon: {
    width: 96,
    height: 63,
    top: 22,
  },
  rectangleParent28: {
    left: 0,
  },
  generalSurgeons: {
    textAlign: "left",
  },
  imagesRemovebgPreview1Icon: {
    left: 99,
    width: 54,
  },
  rectangleParent29: {
    left: 154,
  },
  pngTransparentSportsMedicinIcon: {
    top: 22,
  },
  rectangleParent30: {
    left: 0,
  },
  rectangleParent31: {
    display: "none",
    left: 154,
  },
  urologists: {
    left: 40,
    top: 96,
    textAlign: "center",
    fontFamily: FontFamily.latoMedium,
    fontWeight: "500",
    fontSize: FontSize.size_sm,
    color: Color.lightLabelPrimary,
    position: "absolute",
  },
  urologistIcon1: {
    top: 22,
  },
  rectangleParent32: {
    left: 0,
  },
  groupParent: {
    height: 2332,
    left: 0,
  },
  doctorInner: {
    top: 259,
    left: 30,
    height: 510,
  },
  doctor: {
    borderRadius: Border.br_21xl,
    flex: 1,
    height: 792,
    width: "100%",
    backgroundColor: Color.white,
  },
});

export default DoctorList;
