import * as React from "react";
import { StyleSheet, View, Text, Image } from "react-native";
import { FontFamily, Color, FontSize, Border } from "../GlobalStyles";

const LoginMedexpertz = () => {
  return (
    <View style={styles.loginMedexpertz}>
      <View
        style={[
          styles.asPatientsButton,
          styles.buttonLayout,
          styles.buttonPosition,
        ]}
      >
        <View
          style={[
            styles.asPatientsButtonChild,
            styles.image2IconPosition,
            styles.buttonLayout,
          ]}
        />
        <Text
          style={[styles.loginAsPatient, styles.loginTypo, styles.loginTypo1]}
        >{`Login As
Patient`}</Text>
      </View>
      <View
        style={[
          styles.asDoctorButton,
          styles.buttonLayout,
          styles.buttonPosition,
        ]}
      >
        <View
          style={[
            styles.asPatientsButtonChild,
            styles.image2IconPosition,
            styles.buttonLayout,
          ]}
        />
        <Text
          style={[styles.loginAsDoctor, styles.loginTypo, styles.loginTypo1]}
        >{`Login
As
Doctor`}</Text>
      </View>
      <View style={[styles.logo, styles.logoLayout]}>
        <Image
          style={[styles.logoLayout, styles.image2IconPosition]}
          resizeMode="cover"
          source={require("../assets/image-2.png")}
        />
      </View>
      <Text style={[styles.medexpertz, styles.loginTypo]}>
        <Text style={styles.med}>MED</Text>
        <Text style={styles.expertz}>EXPERTZ</Text>
      </Text>
    </View>
  );
};

const styles = StyleSheet.create({
  buttonLayout: {
    height: 101,
    width: 133,
    position: "absolute",
  },
  buttonPosition: {
    top: 472,
    width: 133,
    position: "absolute",
  },
  image2IconPosition: {
    left: 0,
    top: 0,
  },
  loginTypo: {
    textAlign: "center",
    fontFamily: FontFamily.poppins,
    fontWeight: "700",
    position: "absolute",
  },
  loginTypo1: {
    color: Color.white,
    fontSize: FontSize.size_xl,
    left: 28,
    textAlign: "center",
    fontFamily: FontFamily.poppins,
    fontWeight: "700",
  },
  logoLayout: {
    height: 120,
    width: 250,
    position: "absolute",
  },
  asPatientsButtonChild: {
    borderRadius: Border.br_8xs,
    backgroundColor: Color.teal_100,
    width: 133,
    position: "absolute",
    top: 0,
  },
  loginAsPatient: {
    top: 15,
    width: 81,
    height: 72,
  },
  asPatientsButton: {
    left: 41,
  },
  loginAsDoctor: {
    top: 19,
    width: 78,
    height: 64,
  },
  asDoctorButton: {
    left: 185,
  },
  logo: {
    top: 218,
    left: 49,
  },
  med: {
    color: Color.darkslateblue,
  },
  expertz: {
    color: Color.tomato_100,
  },
  medexpertz: {
    top: 379,
    left: 54,
    fontSize: 36,
    textAlign: "center",
    fontFamily: FontFamily.poppins,
    fontWeight: "700",
  },
  loginMedexpertz: {
    borderRadius: Border.br_21xl,
    backgroundColor: Color.whitesmoke_300,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    flex: 1,
    width: "100%",
    height: 792,
  },
});

export default LoginMedexpertz;
